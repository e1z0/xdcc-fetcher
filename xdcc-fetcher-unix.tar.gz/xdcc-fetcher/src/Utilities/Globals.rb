# This file contains all global variables of XDCC-Fetch.

# Copyright (c) 2004-2005, Christoph Heindl and Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#      may be used to endorse or promote products derived from this software without specific 
#      prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

require 'src/Utilities/Recursive_Open_Struct'

$cfg = Recursive_Open_Struct.new

$cfg.app.name = "XDCC-Fetcher"
$cfg.app.version = "DEADMAN"

$cfg.app.revision = "1.433-R1"

$cfg.app.developers = [
  "/dev/null (SSL hack implemetation, languages and windows port)",
	"Martin Ankerl (GUI)", 
	"Christoph Heindl (Network)",
	"Marlene Gugimaier (Testing, User Interface)",
]
$cfg.app.thanks = [
	"The Ruby Community (http://ruby-lang.org/)",
	"FXRuby Team (http://www.fxruby.org/)",
	"Fox-Toolkit Team (http://fox-toolkit.org/)",
	"Everaldo for Crystal-SVG (http://www.everaldo.com/)"
]
$cfg.app.copyright = "Copyright (c) 2009-2010 /dev/null"
$cfg.app.url = "http://null.people.bsdnet.net/stuff/xdcc-fetcher/"

# use first font that is available
$cfg.app.font.name = ["Bitstream Vera Sans", "Verdana", "Trebuchet MS", "Tahoma", "Arial"]
$cfg.app.font.size = 8

$cfg.dialogbox.textwidth = 120

$cfg.talkback.name = "Talkback"

$cfg.app.width = 640	
$cfg.app.height = 480
$cfg.left.width = 130
$cfg.bottom.height = 150
$cfg.list.opts = ICONLIST_SINGLESELECT|ICONLIST_DETAILED|LAYOUT_FILL_X|LAYOUT_FILL_Y|ICONLIST_AUTOSIZE # HSCROLLER_NEVER|

# icons
$cfg.icons.clear = "fileclose.png"

$cfg.icons.disconnected = "connect_no.png"
$cfg.icons.connecting = "connect_creating.png"
$cfg.icons.connected = "connect_established.png"
$cfg.icons.connection_failed = "connect_failed.png"
$cfg.alternative_user_name = "XDCC-Fetch_#{rand(36**5).to_s(36)}"

$cfg.icons.warning = "messagebox_warning_small.png"
$cfg.icons.packet = "package.png"
$cfg.icons.active = "folder_inbox.png"
$cfg.icons.completed = "camera_test.png"
$cfg.icons.error = "cancel.png"
$cfg.icons.quit = "exit.png"
$cfg.icons.app = "ark.png"
$cfg.icons.app_big = "ark_big.png"
$cfg.icons.app_mega = "mega_ark.png"
$cfg.icons.add = "edit_add.png"
$cfg.icons.remove = "edit_remove.png"
$cfg.icons.free_slots = "ark.png"
$cfg.icons.slots_unknown = "package_unknown.png"
$cfg.icons.package_failed = "package_favourite.png"
$cfg.icons.about = "idea.png"
$cfg.icons.cancel = "cancel.png"
$cfg.icons.error_big = "messagebox_critical.png"
$cfg.icons.warning_big = "messagebox_warning.png"
$cfg.icons.translations = "locale.png"

# parameters for network code
$cfg.network.tcp.connect_timeout = 30
$cfg.network.tcp.connect_thread_priority = -2
$cfg.network.dcc.send_regexp = /^DCC\sSEND\s(\S+)\s(\d+)\s(\d+)\s(\d+)$/i
$cfg.network.dcc.accept_regexp = /^DCC\sACCEPT\s(\S+\s)?\s*(\d+)\s(\d+)$/i
$cfg.network.dcc.enable_verification = true
$cfg.network.dcc.verification_bytes = 20_000
$cfg.network.dcc.block_nonroutable_addresses = true
$cfg.network.ctcp.enable_replies = true
$cfg.network.irc.default_port = 6667
$cfg.network.irc.msg_regexp = /^(:\S*\s)?(\S*)\s?(.*)?$/
$cfg.network.irc.prefix_regexp = /^:([^!\s]*)!?([^@\s]*)?@?(\S*)?\s/
$cfg.network.irc.params_regexp = /:.+|\S+/
$cfg.network.xdcc.offer_regexp = /^\002\*{2}\002\D*(\d+)[^\002]*\002\*{2}\002\D*(\d+)\D*(\d+).*$/
$cfg.network.xdcc.queue_regexp = /Queue:\s(\d+)\/(\d+)/
$cfg.network.xdcc.pack_regexp = /\002#(\d+)\s*\002\D*(\d+)x\D*\[([^\]]*)\]\s*(.*)/
# bugfixed version
#$cfg.network.xdcc.pack_regexp = /#(\d+)\s*\D*(\d+)x\D*\[([^\]]*)\]\s*(.*)/
$cfg.network.xdcc.queue_add_regexp = /Added\syou\sto\sthe\smain\squeue\sin\sposition\s(\d+)/i
$cfg.network.xdcc.punish_slowness_regexp = /You\sare\sbeing\spunished\sfor\syour\sslowness/i
$cfg.network.xdcc.queue_full_regexp = /Main\squeue\sof\ssize\d+\sis\full/i
$cfg.network.xdcc.queue_full_wait = 60
$cfg.network.xdcc.is_queued_regexp = /You\s\already\shave\sthat\sitem\squeued/i
$cfg.network.xdcc.is_queued_wait = 60
$cfg.network.xdcc.max_queued_regexp = /You\salready\shave\s\d+\sitems\squeued/i
$cfg.network.xdcc.max_queued_wait = 60
$cfg.network.xdcc.queue_update_regexp = /in\sposition\s(\d+)\sof\s(\d+)/i
$cfg.network.xdcc.request_timeout = 20
$cfg.network.xdcc.max_rerequests = 5
$cfg.network.xdcc.no_max_rerequests = true
$cfg.network.xdcc.con_error_wait = 20
$cfg.network.xdcc.enable_md5 = true
$cfg.network.xdcc.md5_regexp = /md5sum: (\w+)\)/i


$cfg.config_filename = File.join(ENV['HOME'] || ENV['USERPROFILE'] || ENV['HOMEPATH'], ".xdcc-fetch.conf")

# $cfg.config is managed by the configuration class.
# The following values are default values which might be overridden by the config file.
$cfg.config.current_language = 'en'
$cfg.config.servers = { }
$cfg.config.download_directory = "."

# load all language files
Dir['src/Translations/*.rb'].each do |language_file|
	require language_file
end

$cfg.text = Recursive_Open_Struct.new

# prevent further modifications
$cfg.close
