# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


require 'set'

# Provides a generic interface for an event based publisher/subscriber pattern.
# Subscribers may only register/unregister for certain events, given by a bitmask.
# Subscribers need to provide a generic notify method on_event, which has three
# parameters: 1. event trigger, 2. type of the event, and 3. array of event arguments
module Event_Publisher

	@@global_event_id = 1
	
	def init_events
		@event_listeners = Hash.new()
	end
	
	def shutdown_events
		@event_listeners = nil
	end
	
	def events_of_nr(n)
		tmp = [n, 0]
		events = []
		i = 0
		begin
			tmp = tmp[0].divmod(2)
			events.push(2**i) unless tmp[1] == 0
			i += 1
		end while tmp[0] != 0
		events
	end
	
	def connect_to_events(events, listener)
		self.events_of_nr(events).each do |event|
			if !@event_listeners.include?(event)
				@event_listeners[event] = Set[listener]
			else
				@event_listeners[event].add(listener)
			end
		end
	end
		
	def disconnect_from_events(events, listener)
		self.events_of_nr(events).each do |event|
			if @event_listeners.include?(event)
				@event_listeners[event].delete(listener)
			end
		end
	end
		
	def fire_event(events, *eventargs)
		self.events_of_nr(events).each do |event|
			if @event_listeners.include?(event)
				@event_listeners[event].each do |listener|
					listener.on_event(self, event, eventargs)
				end
			end
		end
	end
		
	def Event_Publisher.next_global_eventID
		@@global_event_id *= 2
	end
end