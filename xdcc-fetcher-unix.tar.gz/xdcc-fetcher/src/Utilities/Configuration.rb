# Copyright (c) 2004-2005, Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#      may be used to endorse or promote products derived from this software without specific 
#      prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

require 'yaml'

# Configuration is responsible for loading and saving XDCC-Fetch's settings that are
# configurable by the user.
class Configuration
	def initialize(whole_config)
		@whole_config = whole_config
		@config = whole_config.config
		@lang = whole_config.text
	end
	
	# Loads configuration parameters, and the language.
	def load
		load_saved_config
		set_language("en")
		set_language(@config.current_language) if @config.current_language != "en"
	end
	
	# Saves the configuration into a YAML file.
	def save
		save_config
	end
	
	private

	def save_config
		data = { }
		@config.attrs.each do |attr|
			data[attr] = @config[attr]
		end
		File.open(@whole_config.config_filename, "wb") do |file|
			file.write(YAML::dump(data))
		end
	end
	
	def load_saved_config
		@config.re_open
		data = { }
		begin
			File.open(@whole_config.config_filename) do |file|
				data = YAML::load(file.read)
			end
		rescue Errno::ENOENT
		end
		data.each do |key, value|
			@config[key] = value
		end
		@config.close
	end
		
	def set_language(lang_id)
		@lang.re_open
		copy(@whole_config.translations[lang_id], @lang)
		@lang.close
	end
	
	def copy(source, target)
		source.attrs.each do |attr|
			if source[attr].class == Recursive_Open_Struct
				target[attr] ||= Recursive_Open_Struct.new
				copy(source[attr], target[attr])
			else
				target[attr] = source[attr]
			end
		end
	end
end
