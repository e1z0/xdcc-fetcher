# Copyright (c) 2009, 2010 (c) mixman
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#      may be used to endorse or promote products derived from this software without specific 
#      prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Language definition #################################

lang = $cfg.translations.lt
lang.language_name = "Lithuanian"

lang.about = "&Apie\t\tParodys informaciją apie programos kūrėjus"
lang.help = "&Pagalba"
lang.add_server = "&Pridėti serverį\tCtrl-A\tPrideda naują serverį bei prie jo prisijungia"
lang.remove_server = "Išimti\t\tAtsijungia bei pašalina serverį"
lang.add_channel = "Pridėti kanalą\t\tPrideda kanalą bei prie jo prisijungia"
lang.add_channel_dialog = "Kanalo pridėjimas"
lang.remove_channel = "Pašalinti\t\tIšeina iš kanalo bei pašalina jį iš sąrašo"
lang.specify_server = "Nurodykite serverį"

lang.server = "Serveris"
lang.port = "Prievadas"
lang.nickname = "Nickas"
lang.password = "Slaptažodis"
lang.channel = "Kanalas"

lang.disconnect = "&Atsijungti"
lang.connect = "&Prisijungti"


lang.file = "&Failas"
lang.quit = "&Išeiti\tCtrl-X\tUždaro programą bei visus aktyvius prisijungimus"

lang.speed_widget_init = "0.0 kb\tParodo totalų parsisiuntimo greitį kilobaitais\tParodo totalų parsisiuntimo greitį kilobaitais"

lang.enter_ip_or_domain = "Parašykite IP arba domeną"
lang.the_servers_port = "Parašykite prievadą (port)"

lang.channel_name = "Kanalo pavadinimas"
lang.connections = "Prisijungimai\tSpausk su kairiu pėlės klavišu į pažymėtą vietą\nto Pridėti IRC serverius ir kanalus\tSpausk su kairiu pėlės klavišu į pažymėtą vietą, kad pridėtum irc serverius arba kanalus"
lang.search = "Paieška\tĮrašykite norimą teksta paieškai\tĮrašykite norimą teksta paieškai"

lang.free_slots = "\tRodyti/slėpti paketus kurių\nbotas turi laisvų vietų\tRodyti/Slėpti paketus kurių botas turi laisvų vietų"
lang.slots_unknown = "\tRodyti/Slėpti paketus\nkurių statusas yra nežinomas\tRodyti/Slėpti paketus kurių statusas yra nežinomas"
lang.no_free_slots = "\tRodyti/Slėpti paketus kurių\nbotas neturi laisvų vietų\tRodyti/slėpti paketus kurių botas neturi laisvų vietų"

lang.what_do_you_want_to_fetch_today = "Ką norite parsisiųsti ?"

lang.bot = "Botas"
lang.name = "Pavadinimas"
lang.size = "Dydis"

lang.active = "Aktyvūs\tRodo aktyvius parsiuntimus\tRodo aktyvius parsiuntimus"
lang.completed = "Užbaigti\tRodo užbaigtus parsiuntimus\tRodo užbaigtus parsiuntimus"
lang.error = "Nepavykę\tRodo sustabdytus parsiuntimus\tRodo sustabdytus parsiuntimus"

lang.download = "&Parsisiųsti\t\tParsisiųsti šį paketą"
lang.status = "Statusas"
lang.target_directory = "Parsisiuntimo katalogas"
lang.clear_list = "&Išvalyti sąrašą"

lang.download_waiting = "Laukiama"
lang.download_requesting = "Prašoma"
lang.download_timeout = "Baigėsi laikas"
lang.download_cancelling = "Nutraukiama"
lang.download_started = "Siunčiama"
lang.download_finished = "Pabaigta"
lang.download_failed = "Nepavyko"
lang.queue_remote = "Nutolusiai užlaikyta: "
lang.queue_local = "Lokaliai užlaikyta: "
lang.speed = "Greitis"

lang.version = "Versija"
lang.revision = "Revizija"
lang.credits = "Programuotojai"
lang.thanks = "Dėkojame"


# "x of x packs"
lang.of = "/"
lang.packs = ""
lang.status_label_tooltip = "\tRodo skaičių matomų\npaketų / totalų paketų skaičių\tRodo matomų paketų skaičių / totalų paketų skaičių"

lang.cancel = "&Atšaukti\t\tAtšauks parsisiuntimą"
lang.submit = "&Vykdyti"

lang.md5.disabled = "išjungta"
lang.md5.unavailable = "nežinoma"
lang.md5.ok = "gera"
lang.md5.failed = "bloga"

lang.checksum = "Patikra"

lang.speed = "Greitis"

lang.version = "Versija"
lang.revision = "Revizija"
lang.credits = "Kreditai"

lang.download_finished_box = "Parsisiuntimas baigtas"

lang.show_warning = "&Rodyti klaidą"
lang.options = "&Nustatymai"
lang.language = "&Kalba"

lang.you_have_to_restart = "Perkraukite XDCC-Fetch kad nustatymai būtų pakeisti"

# Network messages
lang.network.ip.err_notroutable_ip = "Pateiktas neatsekamas ip ądresas"
lang.network.tcp.err_invalid_address = "Nenormali IP addreso/prievado informacija"
lang.network.tcp.err_con_closed = "Prisijungimas uždarytas"
lang.network.tcp.err_con_active = "Prisijungimas yra aktyvus"
lang.network.tcp.err_con_timeout = "Baigėsi laikas bandant prisijungti"
lang.network.tcp.err_con_no_remote = "Nėra nurodyta adreso ar/arba porto"
lang.network.dcc.err_dir_notexist = "Parsiuntimo katalogas neegzistuoja"
lang.network.dcc.err_file_permission = "Neįmanoma rašyti į failą"
lang.network.dcc.err_filesize_differ = "Failo dydis atrodo gali skirtis"
lang.network.dcc.err_verification = "Filo patikra nepavyko"
lang.network.xdcc.err_punish_slowness = "Parsisiuntimo greitis botui pasirodė per lėtas"
lang.network.xdcc.err_pack_already_requested = "Paketas jau yra siunčiamas"
lang.network.xdcc.err_max_packs_requested = "Maksimalus numeris boto paketų"
lang.network.xdcc.err_bot_left = "Botas išėjo"
lang.network.xdcc.err_server_disconnect = "Atsijungėme nuo IRC serverio"
lang.network.xdcc.err_con_closed = "Prisijungimas buvo nutolusiai nutrauktas"
lang.network.xdcc.err_no_answer = "Negavome XDCC atsakymo"
lang.network.xdcc.err_ip_address_conversion = "Neįmanoma nustatyti IP adreso"
lang.network.xdcc.cancel_download_default = "Vartotojas nutraukė siuntimą"


lang.message.connection_error_title = "Prisijungimo klaida"
lang.message.connection_error = "Prisijungimas prie IRC serverio nepavyko"