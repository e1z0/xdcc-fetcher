# Copyright (c) 2004, 2005 Christoph Heindl and Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#      may be used to endorse or promote products derived from this software without specific 
#      prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Language definition #################################

lang = $cfg.translations.pl
lang.language_name = "Polish"

lang.about = "&O programie\t\tPokazuje okno dialogowe O programie"
lang.help = "&Pomoc"
lang.add_server = "&Dodaj serwer\tCtrl-A\tDodaje i ��czy si� z serwerem IRC"
lang.remove_server = "Usu�\t\tRoz��cza i usuwa serwer IRC"
lang.add_channel = "Dodaj kana�\t\tDodaje (wchodzi) kana�"
lang.add_channel_dialog = "Dodaj kana�"
lang.remove_channel = "Usu�\t\tUsuwa (opuszcza) kana�"
lang.specify_server = "Okre�l serwer"

lang.server = "Serwer"
lang.port = "Port"
lang.nickname = "Nick"
lang.password = "Has�o"
lang.channel = "Kana�"

lang.disconnect = "&Roz��cz"
lang.connect = "&Po��cz"


lang.file = "&Plik"
lang.quit = "&Wyj�cie\tCtrl-X\tZamyka program i wszystkie aktywne po��czenia"

lang.speed_widget_init = "0.0 kb\tPokazuje ca�kowit� pr�dko�� pobierania w kilobajtach\tPokazuje ca�kowit� pr�dko�� pobierania w kilobajtach"

lang.enter_ip_or_domain = "Wpisz IP lub domen�"
lang.the_servers_port = "Port serwera"

lang.channel_name = "Nazwa kana�u"
lang.connections = "Po��czenia\tPrawoklik na zasadniczym obszarze\naby doda� serwery IRC oraz kana�y\tPrawoklik na zasadniczym obszarze aby doda� serwery IRC oraz kana�y"
lang.search = "Szukaj\tWpisz swoje zapytanie w pole po prawej\tWpisz swoje zapytanie w pole po prawej"

lang.free_slots = "\tPoka�/ukryj pakiety gdzie\nbot ma wolne sloty\tPokazuje/ukrywa pakiety gdzie bot ma wolne sloty"
lang.slots_unknown = "\tPoka�/ukryj pakiety gdzie\nilo�� slot�w jest nieznana\tPokazuje/ukrywa pakiety gdzie ilo�� slot�w jest nieznana"
lang.no_free_slots = "\tPoka�/ukryj pakiety gdzie\nbot nie posiada wolnych slot�w\tPokazuje/ukrywa pakiety gdzie bot nie posiada wolnych slot�w"

lang.what_do_you_want_to_fetch_today = "Co chcesz dzisiaj �ci�gn��?"

lang.bot = "Bot"
lang.name = "Nazwa"
lang.size = "Rozmiar"

lang.active = "Aktywne\tPokazuje aktywne pobierania\tPokazuje aktywne pobierania"
lang.completed = "Zako�czone\tPokazuje zako�czone pobierania\tPokazuje zako�czone pobierania"
lang.error = "B��d\tPokazuje przerwane pobierania\tPokazuje przerwane pobierania"

lang.download = "&Pobierz\t\tPobierz tego packa"
lang.status = "Status"
lang.target_directory = "Katalog pobiera�"
lang.clear_list = "&Czy�� list�"

lang.download_waiting = "Oczekiwanie"
lang.download_requesting = "��danie"
lang.download_timeout = "Timeout"
lang.download_cancelling = "Anulowanie"
lang.download_started = "Pobieranie"
lang.download_finished = "Uko�czone"
lang.download_failed = "Nieudane"
lang.queue_remote = "Zdalnie zakolejkowane: "
lang.queue_local = "Lokalnie zakolejkowane: "
lang.speed = "Szybko��"

lang.version = "Wersja"
lang.revision = "Podwersja"
lang.credits = "Developerzy"
lang.thanks = "Specjalne podzi�kowania dla"


# "x of x packs"
lang.of = "/"
lang.packs = ""
lang.status_label_tooltip = "\tPokazuje ilo�� widocznych\npack�w / ca�kowit� ilo�� pack�w\tPokazuje ilo�� widocznych pack�w / ca�kowit� ilo�� pack�w"

lang.cancel = "&Anuluj\t\tAnuluje pobieranie"
lang.submit = "&Wy�lij"

lang.md5.disabled = "nieznane"
lang.md5.unavailable = "nieznane"
lang.md5.ok = "ok"
lang.md5.failed = "z�e"

lang.checksum = "Suma kontrolna"

lang.speed = "Szybko��"

lang.version = "Wersja"
lang.revision = "Podwersja"
lang.credits = "Podzi�kowania"

lang.download_finished_box = "Pobieranie zako�czone"

lang.show_warning = "&Poka� b��d"

# Network messages
lang.network.ip.err_notroutable_ip = "Nie wpisano rutowalnego adresu ip"
lang.network.tcp.err_invalid_address = "Nieprawid�owe info o adresie/porcie TCP"
lang.network.tcp.err_con_closed = "Po��czenie zosta�o zamkni�te"
lang.network.tcp.err_con_active = "Po��czenie jest aktywne"
lang.network.tcp.err_con_timeout = "Timeout podczas pr�by po��czenia"
lang.network.tcp.err_con_no_remote = "Nie zosta� okre�lony adres i/lub port"
lang.network.dcc.err_dir_notexist = "Nie istnieje katalog docelowy"
lang.network.dcc.err_file_permission = "Nie mo�na zapisa� do pliku"
lang.network.dcc.err_filesize_differ = "Rozmiar pliku wygl�da na inny"
lang.network.dcc.err_verification = "Nieudana weryfikacja pliku"
lang.network.xdcc.err_punish_slowness = "Zbyt ma�a pr�dko�c pobierania od bota"
lang.network.xdcc.err_pack_already_requested = "Ju� za��dano tego packa"
lang.network.xdcc.err_max_packs_requested = "Max ilo�� pack�w ��danych od bota"
lang.network.xdcc.err_bot_left = "Bot opu�ci� IRC"
lang.network.xdcc.err_server_disconnect = "Utracono po��czenie z serwerem IRC"
lang.network.xdcc.err_con_closed = "Po��czenie zosta�o zdalnie zamkni�te"
lang.network.xdcc.err_no_answer = "Brak odpowiedzi XDCC"
lang.network.xdcc.err_ip_address_conversion = "Nie mo�na okre�li� adresu IP"
lang.network.xdcc.cancel_download_default = "U�ytkownik anulowa� pobieranie"


lang.message.connection_error_title = "B��d po��czenia"
lang.message.connection_error = "Nieudane po��czenie z serwerem IRC"