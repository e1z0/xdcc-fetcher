# Copyright (c) 2004, 2005 Christoph Heindl and Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#      may be used to endorse or promote products derived from this software without specific 
#      prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Language definition #################################

lang = $cfg.translations.de
lang.language_name = "German"

lang.about = "&�ber\t\tZeigt �ber-Dialog"
lang.help = "&Hilfe"
lang.add_server = "&Server Hinzuf�gen\tCtrl-A\tF�gt einen IRC Server hinzu und verbindet sich"
lang.remove_server = "Entfernen\t\tBeendet Verbindung mit IRC Server und entfernt ihn"
lang.add_channel = "&Channel Hinzuf�gen\t\tF�gt einen Channel hinzu (join)"
lang.add_channel_dialog = "Channel Hinzuf�gen"
lang.remove_channel = "Entfernen\t\tEntfernt einen Channel (part)"
lang.specify_server = "Server Daten"

lang.server = "Server"
lang.port = "Port"
lang.nickname = "Spitzname"
lang.password = "Passwort"
lang.channel = "Channel"

lang.file = "&Datei"
lang.quit = "&Beenden\tCtrl-X\tSchlie�t die Applikation und beendet alle aktiven Verbindungen"

lang.speed_widget_init = "0.0 kb\tZeigt Gesamtdownloadgeschwindigkeit in Kilobyte\tZeigt Gesamtdownloadgeschwindigkeit in Kilobyte"

lang.enter_ip_or_domain = "IP-Adresse oder Domain-Name"
lang.the_servers_port = "Port des Servers"

lang.channel_name = "Channel Name"
lang.connections = "Verbindungen\tRechte Maustaste im unteren Fenster dr�cken\num einen IRC Server und Channel hinzuzuf�gen\tRechte Maustaste im unteren Fenster dr�cken um einen IRC Server und Channel hinzuzuf�gen"
lang.search = "Suche\tSuchanfragen in die Box eingeben\tSuchanfragen in die Box eingeben"

lang.free_slots = "\tZeige/Verstecke Pakete deren Bot freie Slots hat\tZeige/Verstecke Pakete deren Bot freie Slots hat"
lang.slots_unknown = "\tZeige/Verstecke Pakete deren Bot's Slot-status unbekannt ist\tZeige/Verstecke Pakete deren Bot's Slot-status unbekannt ist"
lang.no_free_slots = "\tZeige/Verstecke Pakete deren Bot keine freien Slots hat\tZeige/Verstecke Pakete deren Bot keine freien Slots hat"

lang.what_do_you_want_to_fetch_today = "Was darf's heute sein?"

lang.bot = "Bot"
lang.name = "Name"
lang.size = "Gr��e"

lang.active = "Aktiv\tZeigt aktive Downloads\tZeigt aktive Downloads"
lang.completed = "Fertig\tZeigt fertige Downloads\tZeigt fertige Downloads"
lang.error = "Abgebrochen\tZeigt abgebrochene Downloads\tZeigt abgebrochene Downloads"

lang.download = "&Herunterladen\t\tLade dieses Pack herunter"
lang.status = "Status"
lang.target_directory = "Zielverzeichnis"
lang.clear_list = "&L�sche Liste"

lang.download_waiting = "Warte"
lang.download_requesting = "Anfordern"
lang.download_timeout = "Zeit�berschreitung"
lang.download_cancelling = "Breche ab"
lang.download_started = "Lade herunter"
lang.download_finished = "Fertig"
lang.download_failed = "Fehler"
lang.queue_remote = "Bot Warteschlange: "
lang.queue_local = "Lokale Warteschlange: "
lang.speed = "Geschwindigkeit"

lang.version = "Version"
lang.revision = "Revision"
lang.credits = "Entwickler"
lang.thanks = "Besonderer Dank an"


# "x of x packs"
lang.of = "/"
lang.packs = ""
lang.status_label_tooltip = "\tZeigt Anzahl der sichtbaren\nPakete / Gesamtanzahl der Pakete\tZeigt Anzahl der sichtbaren Pakete / Gesamtanzahl der Pakete"

lang.cancel = "&Abbrechen\t\tBricht das Herunterladen ab"
lang.submit = "&Submit"

lang.md5.disabled = "unbekannt"
lang.md5.unavailable = "unbekannt"
lang.md5.ok = "Ok"
lang.md5.failed = "Falsch"

lang.checksum = "Pr�fsumme"

lang.speed = "Geschwindigkeit"

lang.download_finished_box = "Fertig Heruntergeladen"

lang.show_warning = "&Fehler Zeigen"
lang.language = "&Sprache"
lang.options = "Optionen"


# Network messages
lang.network.ip.err_notroutable_ip = "IP Adresse nicht kann nicht gerouted werden"
lang.network.tcp.err_invalid_address = "Ung�ltige Zielhost Angabe"
lang.network.tcp.err_con_closed = "Verbindung ist geschlossen"
lang.network.tcp.err_con_active = "Verbindung ist gerade aktiv"
lang.network.tcp.err_con_timeout = "Zeit�berschreitung beim Verbinden"
lang.network.tcp.err_con_no_remote = "Keine Adresse oder Port angegeben"
lang.network.dcc.err_dir_notexist = "Zielverzeichnis existiert nicht"
lang.network.dcc.err_file_permission = "Kann Datei nicht schreiben"
lang.network.dcc.err_filesize_differ = "Dateigr��e unterschiedlich"
lang.network.dcc.err_verification = "Dateiverifikation fehlgeschlagen"
lang.network.xdcc.err_punish_slowness = "Downloadgeschwindigkeit zu gering f�r Bot"
lang.network.xdcc.err_pack_already_requested = "Paket bereits angefordert"
lang.network.xdcc.err_max_packs_requested = "Maximale Anzahl von Paketen vom Bot angefordert"
lang.network.xdcc.err_bot_left = "Bot vom IRC Server ausgestiegen"
lang.network.xdcc.err_server_disconnect = "Verbindung zum IRC Server verloren"
lang.network.xdcc.err_con_closed = "Verbindung wurde beendet"
lang.network.xdcc.err_no_answer = "Keine XDCC Antwort"
lang.network.xdcc.err_ip_address_conversion = "IP Adresse kann nicht festgestellt werden"
lang.network.xdcc.cancel_download_default = "Abbruch durch Benutzer"


lang.message.connection_error_title = "Verbindungsfehler"
lang.message.connection_error = "Verbindung zu IRC-Server abgebrochen"
lang.connect = "&Verbinden"
lang.disconnect = "&Trennen"
