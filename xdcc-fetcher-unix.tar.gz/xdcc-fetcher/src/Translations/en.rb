# Copyright (c) 2004, 2005 Christoph Heindl and Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#      may be used to endorse or promote products derived from this software without specific 
#      prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Language definition #################################

lang = $cfg.translations.en
lang.language_name = "English"

lang.about = "&About\t\tShows an about dialog"
lang.help = "&Help"
lang.add_server = "&Add Server\tCtrl-A\tAdds and connects to an IRC server"
lang.remove_server = "Remove\t\tDisconnects and removes the IRC server"
lang.add_channel = "Add Channel\t\tAdds (joins) a channel"
lang.add_channel_dialog = "Add Channel"
lang.remove_channel = "Remove\t\tRemoves (parts) a channel"
lang.specify_server = "Specify Server"

lang.server = "Server"
lang.port = "Port"
lang.nickname = "Nickname"
lang.password = "Password"
lang.channel = "Channel"

lang.disconnect = "&Disconnect"
lang.connect = "&Connect"


lang.file = "&File"
lang.quit = "&Exit\tCtrl-X\tCloses the application and all active connections"

lang.speed_widget_init = "0.0 kb\tShows total download speed in kilobytes\tShows total download speed in kilobytes"

lang.enter_ip_or_domain = "Enter IP or domain"
lang.the_servers_port = "The server's port"

lang.channel_name = "Channel Name"
lang.connections = "Connections\tRight click in the underlying area\nto add IRC Servers and Channels\tRight click in the underlying area to add IRC Servers and Channels"
lang.search = "Search\tEnter your query in the box to the right\tEnter your query in the box to the right"

lang.free_slots = "\tShow/hide packets where\nbot has free slots\tShow/hide packets where bot has free slots"
lang.slots_unknown = "\tShow/hide packets where\nslot status is unknown\tShow/hide packets where slot status is unknown"
lang.no_free_slots = "\tShow/hide packets where\nbot does not have free slots\tShow/hide packets where bot does not have free slots"

lang.what_do_you_want_to_fetch_today = "What do you want to fetch today?"

lang.bot = "Bot"
lang.name = "Name"
lang.size = "Size"

lang.active = "Active\tShows active downloads\tShows active downloads"
lang.completed = "Completed\tShows completed downloads\tShows completed downloads"
lang.error = "Error\tShows aborted downloads\tShows aborted downloads"

lang.download = "&Download\t\tDownload this pack"
lang.status = "Status"
lang.target_directory = "Download Directory"
lang.clear_list = "&Clear List"

lang.download_waiting = "Waiting"
lang.download_requesting = "Requesting"
lang.download_timeout = "Timeout"
lang.download_cancelling = "Cancelling"
lang.download_started = "Downloading"
lang.download_finished = "Finished"
lang.download_failed = "Failed"
lang.queue_remote = "Remotely Queued: "
lang.queue_local = "Locally Queued: "
lang.speed = "Speed"

lang.version = "Version"
lang.revision = "Revision"
lang.credits = "Developers"
lang.thanks = "Special Thanks To"


# "x of x packs"
lang.of = "/"
lang.packs = ""
lang.status_label_tooltip = "\tShows number of visible\npacks / total pack number\tShows number of visible packs / total pack number"

lang.cancel = "&Cancel\t\tCancels the download"
lang.submit = "&Submit"

lang.md5.disabled = "unknown"
lang.md5.unavailable = "unknown"
lang.md5.ok = "ok"
lang.md5.failed = "wrong"

lang.checksum = "Checksum"

lang.speed = "Speed"

lang.version = "Version"
lang.revision = "Revision"
lang.credits = "Credits"

lang.download_finished_box = "Download Finished"

lang.show_warning = "&Show Error"
lang.options = "&Options"
lang.language = "&Language"

lang.you_have_to_restart = "Restart XDCC-Fetch to apply changes"

# Network messages
lang.network.ip.err_notroutable_ip = "Not routable ip address given"
lang.network.tcp.err_invalid_address = "Invalid TCP address/port info"
lang.network.tcp.err_con_closed = "Connection is closed"
lang.network.tcp.err_con_active = "Connection is currently active"
lang.network.tcp.err_con_timeout = "Timeout while trying to connect"
lang.network.tcp.err_con_no_remote = "No address and/or port specified"
lang.network.dcc.err_dir_notexist = "Destination directory does not exist"
lang.network.dcc.err_file_permission = "Cannot write to file"
lang.network.dcc.err_filesize_differ = "Filesize seems to differ"
lang.network.dcc.err_verification = "File verification failed"
lang.network.xdcc.err_punish_slowness = "Download speed too low for bot"
lang.network.xdcc.err_pack_already_requested = "Pack already requested"
lang.network.xdcc.err_max_packs_requested = "Max number of packs requested from bot"
lang.network.xdcc.err_bot_left = "Bot left IRC"
lang.network.xdcc.err_server_disconnect = "IRC Server connection lost"
lang.network.xdcc.err_con_closed = "Connection remotely closed"
lang.network.xdcc.err_no_answer = "No XDCC answer"
lang.network.xdcc.err_ip_address_conversion = "Could not determine IP address"
lang.network.xdcc.cancel_download_default = "User canceled download"


lang.message.connection_error_title = "Connection Error"
lang.message.connection_error = "Connection to IRC-Server failed"