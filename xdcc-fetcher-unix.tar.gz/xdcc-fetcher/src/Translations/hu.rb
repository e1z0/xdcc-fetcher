# Copyright (c) 2004, 2005 Christoph Heindl and Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#      may be used to endorse or promote products derived from this software without specific 
#      prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Language definition #################################

lang = $cfg.translations.hu
lang.language_name = "Hungarian"

lang.about = "&N�vjegy\t\tA program n�vjegye"
lang.help = "&S�g�"
lang.add_server = "&Szerver hozz�ad�sa\tCtrl-A\tAdds and connects to an IRC server"
lang.remove_server = "T�r�l\t\tSz�tkapcsol�dik a szervert�l �s t�rli a list�b�l"
lang.add_channel = "Szoba hozz�ad�sa\t\tHozz�adja a szob�t a list�hoz, �s bel�p"
lang.add_channel_dialog = "Szoba hozz�ad�sa"
lang.remove_channel = "T�r�l\t\tT�rli a szob�t a list�b�l, �s kil�p bel�le"
lang.specify_server = "Add meg a szervert"

lang.server = "Szerver"
lang.port = "Port"
lang.nickname = "Nickn�v"
lang.password = "Jelsz�"
lang.channel = "Szoba"

lang.disconnect = "Sz�&tkapcsol�d�s"
lang.connect = "&Kapcsol�d�s"


lang.file = "&File"
lang.quit = "Kil�&p�s\tCtrl-X\tKil�p az alkalmaz�sb�l �s minden akt�v kapcsolatb�l is"

lang.speed_widget_init = "0.0 kb\tA let�lt�si sebess�g KByte-ban\tA let�lt�si sebess�g KByte-bans"

lang.enter_ip_or_domain = "Add meg az IP-t vagy domain nevet"
lang.the_servers_port = "A szerver portja"

lang.channel_name = "Szoba neve"
lang.connections = "Kapcsolatok\tJobbklikk a h�tteren\nhogy irc szervert �s/vagy szob�d adj hozz�\thogy irc szervert �s/Jobbklikk a h�tteren vagy szob�d adj hozz�"
lang.search = "Keres�s\tA jobboldali mez�be �rd be hogy mit keresel\tA jobboldali mez�be �rd be hogy mit keresel"

lang.free_slots = "\tMutassa/rejtse el a csomagokat\nahol a botnak van szabad slotja\tMutassa/rejtse el a csomagokat, amikn�l a botnak van szabad slotja"
lang.slots_unknown = "\tMutassa/rejtse el a csomagokat,\nmelyek slot st�tusza ismeretlen\tMutassa/rejtse el a csomagokat, melyek slot st�tusza ismeretlen"
lang.no_free_slots = "\tMutassa/rejtse el a csomagokat,\nahol a botnak nincs szabad slotja\tMutassa/rejtse el a csomagokat, ahol a botnak nincs szabad slotja"

lang.what_do_you_want_to_fetch_today = "Mit szeretne ma let�lteni?"

lang.bot = "Bot"
lang.name = "N�v"
lang.size = "M�ret"

lang.active = "Akt�v\tAz akt�v let�lt�sek mutat�sa\tAz akt�v let�lt�sek mutat�sa"
lang.completed = "Befejezett\tA k�sz let�lt�sek mutat�sa\tA k�sz let�lt�sek mutat�sa"
lang.error = "Hib�s\tA megszak�tott let�lt�sek mutat�sa\tA megszak�tott let�lt�sek mutat�sa"

lang.download = "&Let�lt�s\t\tLet�lti ezt a csomagot"
lang.status = "St�tusz"
lang.target_directory = "Let�lt�si k�nyvt�r"
lang.clear_list = "Lista &t�rl�se"

lang.download_waiting = "V�rakoz�s"
lang.download_requesting = "K�relmez�s"
lang.download_timeout = "Id�t�ll�p�s"
lang.download_cancelling = "T�rl�s"
lang.download_started = "Let�lt�s"
lang.download_finished = "K�sz"
lang.download_failed = "Sikertelen"
lang.queue_remote = "A t�voli v�rakoz�si sorban: "
lang.queue_local = "A helyi v�rakoz�si sorban: "
lang.speed = "Sebess�g"

lang.version = "Verzi�"
lang.revision = "Rev�zi�"
lang.credits = "Fejleszt�k"
lang.thanks = "K�l�n k�sz�net"


# "x of x packs"
lang.of = "/"
lang.packs = ""
lang.status_label_tooltip = "\tA l�that� csomagok sz�m�t\n �s a teljes csomagsz�mot mutatja\tA l�that� csomagok sz�m�t �s a teljes csomagsz�mot mutatja"

lang.cancel = "&Megszak�t�s\t\tMegszak�tja a let�lt�st"
lang.submit = "&Mehet"

lang.md5.disabled = "ismeretlen"
lang.md5.unavailable = "ismeretlen"
lang.md5.ok = "ok"
lang.md5.failed = "hiba"

lang.checksum = "Ellen�rz� �sszeg"

lang.speed = "Sebess�g"

lang.version = "Verzi�"
lang.revision = "Rev�zi�"
lang.credits = "A program alkot�i"

lang.download_finished_box = "A let�lt�s k�sz"

lang.show_warning = "&Hiba mutat�sa"
lang.options = "&Be�ll�t�sok"
lang.language = "&Nyelvek"

lang.you_have_to_restart = "Ind�tsd �jra az XDCC-Fetch-et, hogy a be�ll�t�sok �rv�nybe l�pjenek"

# Network messages
lang.network.ip.err_notroutable_ip = "Nincs route-olhat� IP c�m megadva"
lang.network.tcp.err_invalid_address = "�rv�nytelen TCP c�m/port"
lang.network.tcp.err_con_closed = "A kapcsolat megsz�nt"
lang.network.tcp.err_con_active = "A kapcsolat �l"
lang.network.tcp.err_con_timeout = "Id�t�ll�p�s kapcsol�d�s k�zben"
lang.network.tcp.err_con_no_remote = "Nincs c�m �s/vagy port megadva"
lang.network.dcc.err_dir_notexist = "A c�lk�nyvt�r nem l�tezik"
lang.network.dcc.err_file_permission = "Nem tudok a file-ba �rni"
lang.network.dcc.err_filesize_differ = "Hib�snak t�nik a filem�ret"
lang.network.dcc.err_verification = "A file ellen�rz�se hib�t jelzett"
lang.network.xdcc.err_punish_slowness = "A let�lt�si sebess�g t�l alacsony a bot sz�m�ra"
lang.network.xdcc.err_pack_already_requested = "A csomag m�r volt k�rv�nyezve"
lang.network.xdcc.err_max_packs_requested = "A bott�l m�r nem lehet t�bb csomagot k�rv�nyezni"
lang.network.xdcc.err_bot_left = "A bot kil�pett az IRC szerverr�l"
lang.network.xdcc.err_server_disconnect = "A kapcsolat megsz�nt az IRC szerverrel"
lang.network.xdcc.err_con_closed = "A kapcsolatot a t�voli oldalon megszak�tott�k"
lang.network.xdcc.err_no_answer = "Nincs XDCC v�lasz"
lang.network.xdcc.err_ip_address_conversion = "Nem tudtam meghat�rozni az IP c�met"
lang.network.xdcc.cancel_download_default = "A felhaszn�l� megszak�totta a let�lt�st"


lang.message.connection_error_title = "Kapcsol�d�si hiba"
lang.message.connection_error = "Az IRC szerverhez val� kapcsol�d�s sikertelen volt"