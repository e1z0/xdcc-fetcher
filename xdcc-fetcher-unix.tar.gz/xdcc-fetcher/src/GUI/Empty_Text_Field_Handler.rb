# Copyright (c) 2004, 2005 Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Martin Ankerl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


# Shows a grey text in an FXTextField if the user did not enter any input. This is a nice way to 
# give the user more information about what to enter into a text field, without the need of additional
# space in the GUI.
class Empty_Text_Field_Handler

	# Create a new handler for the specified textfield, with the given text. From now on you have to use the
	# created object to get and set text, not the textfield or this handler would come out of sync
	def initialize(textField, myText)
		@textField = textField
		@myText = myText
		@isEmpty = true
		onTextFieldFocusOut
		# create connections
		@textField.connect(SEL_FOCUSIN, method(:onTextFieldFocusIn))
		@textField.connect(SEL_FOCUSOUT, method(:onTextFieldFocusOut))
	end
	
	# Check if textfield is empty (no user input).
	def empty?
		@isEmpty
	end
	
	# Set new text for the textfield
	def text=(newText)
		onTextFieldFocusIn
		@textField.text = newText.to_s
		onTextFieldFocusOut
	end
	
	# Get the textfield's text, if the user has entered something.
	def text
		if empty? && !@inside
			""
		else
			@textField.text
		end
	end
	
	# Set focus to the textfield.
	def setFocus
		@textField.setFocus
	end

	private
	
	def onTextFieldFocusIn(*args)
		@inside = true
		return if !@isEmpty
		@textField.textColor = FXColor::Black
		@textField.text = ""
	end
	
	def onTextFieldFocusOut(*args)
		@inside = false
		@textField.killSelection
		@isEmpty = @textField.text == ""
		return if !@isEmpty
		@textField.textColor = FXColor::DarkGrey
		@textField.text = @myText
		@isEmpty = true
	end
end
