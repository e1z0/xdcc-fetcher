# Copyright (c) 2005 Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
# * Redistributions of source code must retain the above copyright notice, this list 
#   of conditions and the following disclaimer.
# * Redistributions in binary form must reproduce the above copyright notice, this list 
#   of conditions and the following disclaimer in the documentation and/or other materials 
#   provided with the distribution.
# * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#   may be used to endorse or promote products derived from this software without specific 
#   prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

class Search_Engine
	def initialize(gui, data)
		@gui = gui
		@data = data
	end	
	
	# Executed whenever a search criteria changes to update the packet list.
	def on_search
		# restart current search
		@end_time = Time.now + 0.5
		@restart_search = true
		@gui.search_label.enabled = false
		return if @search_thread && @search_thread.status
			
		@search_thread = Thread.new(@search_thread) do
			begin
				@gui.search_label.enabled = false
				# wait untill deadline
				while (t = (@end_time - Time.now)) > 0
					sleep(t)
				end
				
				@data.gui_mutex.synchronize do
					# the thread has to use the gui mutex inside
					@restart_search = false
					
					match_data = get_match_data
				
					# remove all items
					@gui.packet_list.dirty_clear
					
					# add all items that match the search criteria
					sort_deadline = Time.now
					status_text_deadline = Time.now
					@data.allpack_to_item.each_value do |item|
						#item.parent = @gui.packet_list if match?(item, match_data)
						if match?(item, match_data)
							item.show
							
							# take only about 10% of the cpu to sort items.
							# with few items this results to very fast sorts,
							# with many items this leads to fast updates.
							if (sort_deadline < Time.now)
								before = Time.now
								@gui.packet_list.sortItems
								after = Time.now
								sort_deadline = after + (after-before) *10
							end
							
							# update every 0.1 second
							if (status_text_deadline < Time.now)
								update_search_status_text
								status_text_deadline = Time.now + 0.1
							end
						end
						break if @restart_search
					end
					update_search_status_text
					@gui.packet_list.sortItems
					@gui.search_label.enabled = true
					
				end # synchronize
			end while @restart_search# || match_data != @gui.search_field.text.downcase.split
		end #thread.new
	end
	
	def get_match_data
		str_to_match_data(@gui.search_field.text)
	end

	# Converts a string into a match_data representation.
	def str_to_match_data(str, index=0)
		words = [ ]
		exclude = [ ]
		min = nil
		max = nil
		is_exclude = false
		
		while str[index]
			case str[index]
			when ?", ?'
				word, index = get_word(str, index+1, str[index])
				unless word.empty?
					if is_exclude
						exclude.push word
						is_exclude = false
					else
						words.push word
					end
				end
			
			when 32 # space
				is_exclude = false
				
			when ?>
				min, index = get_word(str, index+1)
				min = @gui.logic.size_to_nr(min)
				
			when ?<
				max, index = get_word(str, index+1)
				max = @gui.logic.size_to_nr(max)
			
			when ?-
				is_exclude = true
			
			else
				word, index = get_word(str, index)
				if is_exclude
					exclude.push word
					is_exclude = false
				else
					words.push word
				end				
			end
			
			index += 1
		end
		[words, exclude, min, max]
	end
	
	def get_word(str, index, delim=32) # 32==space
		word = ""
		c = str[index]
		while (c && c != delim)
			word += c.chr
			index += 1
			c = str[index]
		end
		[word, index]
	end

	# Update the text for the number of displayed packs.
	def update_search_status_text
		@gui.search_status_label.text = " #{@gui.packet_list.numItems} #{$cfg.text.of} #{@data.allpack_to_item.size} #{$cfg.text.packs}"
	end

	# Find out if item is matched by current search criteria.
	def match?(item, match_data)
		# check icon
		return false unless @data.packet_icon_to_toggle_btn[item.icon].toggled?
		
		words, exclude, min, max = match_data
		
		# check size
		size = -item.sortable(2)
		return false if (min && size < min) || (max && size > max)
		
		# check text that has to be there
		item_str = item.sortable(1)
		words.each do |match_str|
			return false unless item_str.include?(match_str)
		end
		
		# check text not allowed to be there
		exclude.each do |match_str|
			# the next items are not allowed to be contained in pack name
			return false if item_str.include?(match_str)
		end
		
		# each check ok
		true
	end
end
