# Copyright (c) 2004, 2005, 2007 Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
# * Redistributions of source code must retain the above copyright notice, this list 
#   of conditions and the following disclaimer.
# * Redistributions in binary form must reproduce the above copyright notice, this list 
#   of conditions and the following disclaimer in the documentation and/or other materials 
#   provided with the distribution.
# * Neither the name of Martin Ankerl nor the names of its contributors may be used to 
#   endorse or promote products derived from this software without specific prior written 
#   permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Load FXRuby: try gem, then Fox 1.2, then Fox 1.0, then Fox 1.6.
begin
	# try fxruby gem
	require 'rubygems'
	require 'fxruby'
	require 'fox12'
	require 'fox12/colors'
	FOXVERSION="1.2"
	include Fox
rescue LoadError
	# no gem? try fox12 direct.
	begin
		require "fox12"
		require "fox12/colors"
		FOXVERSION="1.2"
		include Fox
	rescue LoadError
		# no gem, no fox12? try fox 1.0
		begin
			require "fox"
			require "fox/colors"
			# grep for FOXVERSION to find all code that depends on this
			FOXVERSION="1.0"
			include Fox
			FXMenuBar = FXMenubar
			FXToolTip = FXTooltip
			FXStatusBar = FXStatusbar

		rescue LoadError
			# no fox 1.0? try 1.6
			gem 'fxruby', '>= 1.1.0'
			require 'fox16'
			require 'fox16/colors'
			FOXVERSION="1.6"
			include Fox
		end
	end
end

require 'thread'

require 'src/Utilities/Globals'
require 'src/Utilities/Configuration'
require 'src/GUI/Gui_Logic'
require 'src/GUI/Icon_Loader'
require 'src/GUI/Empty_Text_Field_Handler'
require 'src/GUI/Packet_List'
require 'src/GUI/Custom_Tabs'
require 'src/GUI/Context_Menu'
require 'src/GUI/Dialog_Box'
require 'src/GUI/Speed_Widget'
require 'src/GUI/Toggle_Button'
require 'src/GUI/About_Dialog'
require 'src/GUI/Download_Finished_Box'
require 'src/GUI/Application_Builder'
require 'src/GUI/Gui_Logic'
require 'src/GUI/Search_Engine'

require 'src/Network/IRC_Server'
require 'src/Network/XDCC_Announcement_Storage'
require 'src/Network/XDCC_Download_Handler'
require 'src/Network/XDCC_Parser'

class FXTreeList

	attr_reader :clickedItem

	def init_clickedItem
		self.connect(SEL_LEFTBUTTONPRESS) do |sender, sel, data|
			@clickedItem = self.item_from_pos(data.click_x, data.click_y)
			if @clickedItem
				self.selectItem(@clickedItem, false)
			else
				self.killSelection(false)
			end
		end
		
		self.connect(SEL_RIGHTBUTTONPRESS) do |sender, sel, data|
			@clickedItem = self.item_from_pos(data.click_x, data.click_y)
			if @clickedItem
				self.selectItem(@clickedItem, false)
			else
				self.killSelection(false)
			end
		end
	end
	
	def hit_rec(x, y, item)
		return item if self.hitItem(item, x, y) != 0
		i = nil
		item.each do |child|
			break if i = self.hit_rec(x, y, child)
		end
		i
	end
	
	def item_from_pos(x, y)
		i = nil
		self.each do |item|
			break if i = self.hit_rec(x, y, item)
		end
		i
	end
end

# Responsible for application initialization
class Main_Window < FXMainWindow

	# Initializes the XDCC-application.
	def initialize(app)
		#app.disableThreads
		@data = Recursive_Open_Struct.new
		@gui = Recursive_Open_Struct.new
		@logic = Gui_Logic.new(@gui, @data)
		@gui.logic = @logic
		
		
		# load configuration
		@data.config = Configuration.new($cfg)
		@data.config.load
		init_variables
		@data.close

		# setup main window
		$main_window = self
		super(app, $cfg.app.name, nil, nil, DECOR_ALL, 0, 0, $cfg.app.width, $cfg.app.height)
		set_default_font
		FXToolTip.new(FXApp::instance, TOOLTIP_NORMAL)
		
		# load icons
		icon_loader = Icon_Loader.new(FXApp::instance)
		icon_loader.cfg_to_icons($cfg.icons)
		self.icon = $cfg.icons.app_big
		self.miniIcon = $cfg.icons.app
		
		# build base layout, and connections to logic.
		@gui.main_window = self
		Application_Builder.new(self, @gui, @data, @logic)
		
		# TODO start
		@logic.connect_to_saved_servers
	end
	
	# Automatically called when the Fox application is created
	def create
		super
		@logic.update_search_status_text
		show(PLACEMENT_SCREEN)
	end

	# Set the default font to the first font of $cfg.app.font.name that is available on this system.
	def set_default_font
		# load default font
		font = nil
		$cfg.app.font.name.detect do |name|
			next if FXFont.listFonts(name).empty?
			font = FXFont.new(FXApp::instance, name, $cfg.app.font.size)
		end
		FXApp::instance.normalFont = font if font
	end

	# TODO remove 
	# Set up all variables.
	def init_variables
		@data.match_data = ""
		@data.server_item_to_warning = Hash.new
		@data.packet_icon_to_toggle_btn = Hash.new
		@data.detached_items = Array.new
		@data.allpack_to_item = Hash.new
		@data.gui_mutex = Mutex.new
		@data.irc_server_to_item = Hash.new
		@data.downloadpack_to_item = Hash.new
		@data.server_to_channels = Hash.new
		@data.server_item_to_status = Hash.new
		@data.ann_parser = XDCC_Parser.iroffer_parser
		@data.ann_storage = XDCC_Announcement_Storage.new(@data.ann_parser)
		@data.ann_storage.connect_to_events(XDCC_Announcement_Storage::ON_ANNOUNCEMENT_NEW, @logic)
		@data.ann_storage.connect_to_events(XDCC_Announcement_Storage::ON_ANNOUNCEMENT_LOST, @logic)
		@data.download_handlers = Hash.new
	end	

	# debugging stuff
	def just_testing
		icons = [$cfg.icons.packet, $cfg.icons.free_slots, $cfg.icons.slots_unknown]
		5000.times do |i|
			# set slot representing icon
			icon = icons[rand(3)]
			# create an unconnected item
			name = rand(1e10).to_s(36).upcase + " " + rand(1e10).to_s(36) 
			item = Packet_Item.new(nil, icon, "bot-#{rand(1e3)}", name, rand(100).to_s + ["M","K","G"][rand(3)])
			@data.allpack_to_item[i] = item
			# item needs to be added to a list, before calling match()
			item.parent = @gui.packet_list
			#if !@logic.match?(item, @gui.search_field.text.downcase.split)
				# remove if it does not match
			#	item.parent = nil
			#else
			#	is_added = true
			#end
			#@logic.update_search_status_text
		end
		@logic.update_search_status_text
		#@gui.packet_list.on_cmd_header(2)
		#@gui.packet_list.sortItems
	end
	
	# stress testing
	def stress_test_iconlist
	
		@added=0
		@removed = 0
		@size = 0
		items = Array.new
		100000.times do 
			@data.gui_mutex.synchronize do 
				#add
				icon = [$cfg.icons.packet, $cfg.icons.free_slots, $cfg.icons.slots_unknown][rand(3)]
				10.times do
					item = Packet_Item.new(nil, icon, rand(1e10).to_s(36), rand(1e50).to_s(36), rand(1e4).to_s)
					items.push item
					item.parent = @gui.packet_list
					item.show
					app.forceRefresh
					@size += 1
					@added += 1
				end
				@gui.packet_list.sortItems
				app.forceRefresh
			end
			@data.gui_mutex.synchronize do 
				# remove
				
				rand(items.size/4).times do
					break if items.empty?
					pos = rand(items.size)
					item = items[pos]
					items[pos] = items.last
					items.pop
					item.parent = nil
					app.forceRefresh
					@removed += 1
					@size -= 1
				end
			end
			printf "%5d, %5d, %5d\n", @added, @removed, @size
		end
		puts "Yeah! You got it!!!"
		exit
	end
end

Thread.abort_on_exception= true

$app = FXApp.new($cfg.app.name, $cfg.app.name)
$main_window = Main_Window.new($app)
$app.create
$app.run
