# Copyright (c) 2004,2005 Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Martin Ankerl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


require 'src/GUI/Empty_Text_Field_Handler'

# A convinient dialog box for standard user input like username, password, etc.
class Dialog_Box < FXDialogBox
	# Entry stores the data of one user-input entry of the dialog box
	Entry = Struct.new("Entry", :handler, :opts, :default_value, :is_required, :empty_text)

	# Creates a new Dialog_Box for the parent with the given title.
	def initialize(parent, title)
		super(parent, title, DECOR_TITLE|DECOR_BORDER, 0,0,0,0, 0,0,0,0)
		@parent = parent
		@entries = Array.new
		build_controls
		build_connections
	end
	
	# Add a new entry to the dialog box. for the opts you can specify any FXTextField options like
	# TEXTFIELD_PASSWD,TEXTFIELD_INTEGER etc.
	def add(title, opts=0, default_value=nil, is_required=true, empty_text="")
		# use data to fill dialog box
		FXLabel.new(@matrixFrame, title, nil, LAYOUT_CENTER_Y|JUSTIFY_RIGHT|LAYOUT_FILL_X)
		text_field = FXTextField.new(@matrixFrame, 1, nil, 0, opts|LAYOUT_FILL_COLUMN|LAYOUT_FILL_X|LAYOUT_FIX_WIDTH, 0,0,$cfg.dialogbox.textwidth,0)
		handler = Empty_Text_Field_Handler.new(text_field, empty_text)
		@entries.push Entry.new(handler, opts, default_value, is_required, empty_text)
		text_field.connect(SEL_COMMAND) do |sender, sel, data|
			lastFocus = @matrixFrame.focus
			@ok_btn.setFocus if lastFocus
			on_ok_button if lastFocus
		end
	end
	
	# Displays the dialog box. If OK is pressed, the given block is called with all the user
	# input as parameters.
	def execute(&proc)
		# clear controls
		@entries.each do |entry|
			entry.handler.text = entry.default_value
		end
		# focus first item
		@entries.first.handler.setFocus
		# show dialog
		@proc = proc
		self.show(PLACEMENT_SCREEN)
		app.runModalWhileShown(self)
	end	
	
	private
	
	def build_controls
		FXVerticalFrame.new(self, LAYOUT_FILL_X|LAYOUT_FILL_Y, 0,0,0,0, 0,0,0,0,0,0) do |base|
			FXMatrix.new(base, 2, MATRIX_BY_COLUMNS|LAYOUT_TOP|LAYOUT_FILL_X|LAYOUT_FILL_Y) do |matrix|
				@matrixFrame = matrix
			end
			FXHorizontalSeparator.new(base, LAYOUT_SIDE_BOTTOM|LAYOUT_FILL_X|SEPARATOR_GROOVE)
			FXHorizontalFrame.new(base, LAYOUT_FILL_X, 0,0,0,0) do |button_frame|
				FXHorizontalFrame.new(button_frame, LAYOUT_FILL_X, 0,0,0,0)
				@ok_btn = FXButton.new(button_frame, "&Ok", nil, nil, 0, FRAME_RAISED)
				@cancel_btn = FXButton.new(button_frame, "&Cancel", nil,self, ID_HIDE, FRAME_RAISED)
			end
		end
	end
	
	def build_connections
		@ok_btn.connect(SEL_COMMAND) { on_ok_button }
	end

	# Ensure all required data is available, convert data, and call given proc.
	def on_ok_button
		# check that each text_field contains data
		empty_field = @entries.detect { |entry| entry.is_required && entry.handler.empty? }
		if empty_field
			empty_field.handler.setFocus
		else
			# collect data
			data = Array.new
			@entries.each do |entry|
				if (entry.handler.text == "")
					data.push nil
				elsif (entry.opts & TEXTFIELD_INTEGER != 0)
					data.push entry.handler.text.to_i
				elsif (entry.opts & TEXTFIELD_REAL != 0)
					data.push entry.handler.text.to_f
				else
					data.push entry.handler.text
				end
			end
			self.hide
			@proc.call(data)
		end
	end
end
