# Copyright (c) 2004, 2005 Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
# * Redistributions of source code must retain the above copyright notice, this list 
#   of conditions and the following disclaimer.
# * Redistributions in binary form must reproduce the above copyright notice, this list 
#   of conditions and the following disclaimer in the documentation and/or other materials 
#   provided with the distribution.
# * Neither the name of Martin Ankerl nor the names of its contributors may be used to 
#   endorse or promote products derived from this software without specific prior written 
#   permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

require 'thread'

# The module Business_Logic is included into the Main_Window. It contains all the logic required for the GUI except
# creation stuff.
class Gui_Logic
	CONNECTED = 1
	CONNECTING = 2
	DISCONNECTED = 3
	CONNECTION_FAILED = 4
	
	def initialize(gui, data)
		@gui = gui
		@data = data
		@search_engine = Search_Engine.new(@gui, @data)
	end
	
	def on_search
		@search_engine.on_search
	end
	
	def match?(*args)
		@search_engine.match?(*args)
	end
	
	def update_search_status_text
		@search_engine.update_search_status_text
	end
	
	# Adds a new IRC_server and connects to it.
	def on_add_server_click(menu, sender, sel, data)
		@gui.add_server_box.execute do |ip, port, nick, pwd|
			add_server(ip, port, nick, pwd, true)			
			# add to config
			$cfg.config.servers[ip] = {
				:port => port,
				:nick => nick,
				:pwd => pwd,
				:channels => { },
				:connected => true
			}
			@data.config.save
		end
	end	

	# Retrieves the clicked item of the connection widget, which is a FXTreeList. For FXIconLists like Packet_List 
	# use #current_item.
	def current_connections_item
		@gui.connections.cursorItem
	end
	
	# Retrieves the clicked item of the given Packet_List, or any other FXIconList.
	def current_item(list)
		pos = list.cursorItem
		pos = list.currentItem if (pos == -1)

		if (pos != -1)
			return list.getItem(pos)
		end
		nil
	end
	
	# Convert a string containing a packetsize into the real size which is used for 
	# sorting.Possible strings are e.g. "100M", "43G", "9.9k", etc.
	def size_to_nr(x)
		return 0 if x.nil? || x==""
		x = x.upcase.strip
		fact = 1.0
		char = x[-1]
		# check if there is MB, KB etc.
		char = x[-2] if char == ?B
		case char
		when ?K then fact = 1024
		when ?M then fact = 1024**2
		when ?G then fact = 1024**3
		end
		x.to_f * fact
	end
	
	# Converts a given md5 status text into a representation used for sorting.
	def sortable_md5_status(x)
		case x
		when $cfg.text.md5.ok then 1
		when $cfg.text.md5.disabled then 2
		when $cfg.text.md5.unavailable then 3
		when $cfg.text.md5.failed then 4
		else 5
		end
	end
	
	# Converts a given download status text into a representation used for sorting.
	def sortable_status(x)
		# 2e7: failed
		# 1e7: download finished
		# 0..100: download percentage
		# 0.5: download started
		# -1..-1e7: remote queue position
		# -1e7..-2e7: local queue position
		# - 4e7: waiting
		prev = x
		if x.include?($cfg.text.download_failed)
			x = 2e7
		elsif x == $cfg.text.download_finished
			x = 1e7
		elsif x =~ /%/
			x = x.to_f
		elsif x == $cfg.text.download_started
			x = 0.5
		elsif x.include?($cfg.text.queue_remote)
			/.*\s(\d+)/.match(x)
			x = - $1.to_i
		elsif x.include?($cfg.text.queue_local)
			/.*\s(\d+)/.match(x)
			x = - $1.to_i - 1e7
		elsif x == $cfg.text.download_waiting
			x = -4e7
		else
			x = 3e7
		end
		x
	end
	
	def add_server(ip, port, nick, pwd, do_connect)
		name = "#{ip}"
		server_item = nil
		if FOXVERSION=="1.6"
			server_item = @gui.connections.appendItem(nil, name, $cfg.icons.disconnected, $cfg.icons.disconnected)
		else
			server_item = @gui.connections.addItemLast(nil, name, $cfg.icons.disconnected, $cfg.icons.disconnected)
		end
		@data.server_item_to_status[server_item] = CONNECTING
		# create server
		server = IRC_Server.new
		@data.ann_parser.attach_to_server(server)
		@data.irc_server_to_item[server] = server_item
		server_item.data = server
		server_item.expanded = true
		@gui.connections.sortItems
		if do_connect
			server_item.openIcon = $cfg.icons.connecting
			server_item.closedIcon = $cfg.icons.connecting
			server.connect(ip, port, nick, $cfg.alternative_user_name, pwd)
		end
		connect_to_server_events(server)
		# server -> channelarray
		@data.server_to_channels[server_item] = Array.new
		server_item
	end
	
	# Connect to all servers stored in $cfg.config.servers
	def connect_to_saved_servers
		$cfg.config.servers.each do |ip, data|
			server_item = add_server(ip, data[:port], data[:nick], data[:pwd], data[:connected])
			@data.server_item_to_status[server_item] = data[:connected] ? CONNECTING : DISCONNECTED
			# add channels
			connect_to_saved_channels(server_item)
		end
	end

	def connect_to_saved_channels(server_item)
		server_data = $cfg.config.servers[server_item.text]
		server_data[:channels].each do |channel_name, data|
			add_channel(server_item, channel_name.dup, data[:pwd], server_data[:connected])
		end
	end
	
	# Disconnects from a server.
	def on_remove_server_click(menu, sender, sel, data)
		server_item = menu.data
		# remove from config
		$cfg.config.servers.delete(server_item.text)
		@data.config.save
		# remove
		@data.ann_parser.detach_from_server(server_item.data)
		server_item.data.disconnect
		@data.irc_server_to_item.delete(server_item.data)
		@gui.connections.removeItem(server_item)
	end
	
	def on_server_disconnect_click(menu, sender, sel, data)
		server_item = menu.data
		# set to disconnected, before actually disconnecting.
		# This is used to distinguish between user disconnects, and forced disconnects.
		@data.server_item_to_status[server_item] = DISCONNECTED
		server_item.data.disconnect
		# update config
		$cfg.config.servers[server_item.text][:connected] = false
		@data.config.save
	end
	
	def on_server_connect_click(menu, sender, sel, data)
		server_item = menu.data
		# update config
		$cfg.config.servers[server_item.text][:connected] = true
		@data.config.save
		# connect irc server
		irc_server = server_item.data
		irc_server.disconnect
		server_data = $cfg.config.servers[server_item.text]
		irc_server.connect(server_item.text, server_data[:port], server_data[:nick], $cfg.alternative_user_name, server_data[:pwd])
		# update icons
		server_item.openIcon = $cfg.icons.connecting
		server_item.closedIcon = $cfg.icons.connecting
		# recreate all channels
		@data.server_to_channels[server_item].each do |channel_item|
			@gui.connections.removeItem(channel_item)
		end
		@data.server_to_channels[server_item] = Array.new
		connect_to_saved_channels(server_item)
		
		@data.server_item_to_status[server_item] = CONNECTING
		@gui.connections.recalc
	end
	
	# Joins a channel at the clicked IRC_server.
	def on_add_channel_click(menu, sender, sel, data)
		@gui.join_channel_box.execute do |channel_name, password|
			server_item = menu.data
			do_connect =  (@data.server_item_to_status[server_item] != DISCONNECTED &&
				@data.server_item_to_status[server_item] != CONNECTION_FAILED)
			real_channel_name = add_channel(server_item, channel_name, password, do_connect)
			# add to config
			$cfg.config.servers[server_item.text][:channels][real_channel_name] = { :pwd => password }
			@data.config.save
		end
	end
	
	def add_channel(server_item, channel_name, password, do_connect)
		server_item.expanded = true
		# automatically prepend #
		channel_name = "#" + channel_name unless channel_name[0] == ?#
		channel_name.downcase!
		# check if channel already available
		return if @data.server_to_channels[server_item].detect { |channel_item| channel_item.text == channel_name }
		# create item
		channel_item = nil
		if FOXVERSION=="1.6"
			channel_item = @gui.connections.appendItem(server_item, channel_name, $cfg.icons.disconnected, $cfg.icons.disconnected)
		else
			channel_item = @gui.connections.addItemLast(server_item, channel_name, $cfg.icons.disconnected, $cfg.icons.disconnected)
		end
		if do_connect
			channel_item.openIcon = $cfg.icons.connecting
			channel_item.closedIcon = $cfg.icons.connecting
			server_item.data.join(channel_name, password)
		end
		@data.server_to_channels[server_item].push channel_item
		@gui.connections.sortChildItems(server_item)
		channel_name
	end
		
	# Part channel.
	def on_remove_channel_click(menu, sender, sel, data)
		channel_item = menu.data
		# remove from config
		$cfg.config.servers[channel_item.parent.text][:channels].delete(channel_item.text)
		@data.config.save
		# remove
		channel_item.parent.data.part(channel_item.text)
		@data.server_to_channels[channel_item.parent].delete channel_item
		@gui.connections.removeItem(channel_item)
	end
	
	# Show a nifty �ber-cool about dialog.
	def on_about_click	
		About_Dialog.new(@gui.main_window).execute
	end
	
	# change configured language
	def on_language_change(lang, menu, sender, sel, data)
		@gui.language_radios.each do |radio|
			radio.check = false unless radio == sender
		end
		# update config
		$cfg.config.current_language = lang
		@data.config.save
	end
	
	
	# Let user select a target directory and initiate download if user clicks OK.
	def on_download_click(menu, sender, sel, data)
		fox_item = menu.data
		return if !fox_item
		item = fox_item.packet_item
		packet = item.data
		return if !packet
		dir_dlg = FXDirDialog.new(@gui.main_window, $cfg.text.target_directory)
		dir_dlg.directory = $cfg.config.download_directory
		return if (dir_dlg.execute == 0)
		# save new directory settings, if modified
		new_dir = dir_dlg.directory
		if (new_dir != $cfg.config.download_directory)
			$cfg.config.download_directory = new_dir
			@data.config.save
		end		
		
		# get download handler
		handler = nil
		if (handler = @data.download_handlers[packet.irc_user_bot]) == nil
			handler = @data.download_handlers[packet.irc_user_bot] = XDCC_Download_Handler.new(packet.irc_user_bot)
			handler.connect_to_events(XDCC_Download_Handler::ON_ALL_EVENTS, self)
		end
		
		# add download item
		item = @gui.active_list.create_item($cfg.icons.packet, item[0], item[1], item[2], $cfg.text.download_waiting, "")
		item.fox_item.miniIcon = $cfg.icons.packet
		item.data = packet
		
		# get pack
		@data.downloadpack_to_item[packet] = item
		handler.add_pack(packet, $cfg.config.download_directory)
	end
	
	# Cancels a download.
	def on_cancel_download_click(menu, sender, sel, data)
		fox_item = menu.data
		return if !fox_item
		item = fox_item.packet_item
		packet = item.data
		return if !packet
		
		handler = @data.download_handlers[packet.irc_user_bot]
		item[3] = $cfg.text.download_cancelling
		handler.cancel_pack(packet)
	end
	
	# Remove all items from the error list
	def on_clear_error_list
		@gui.error_list.clear
	end
	
	# Remove all items from the completed list
	def on_clear_completed_list
		@gui.completed_list.clear
	end
	
	def on_show_warning(menu, sender, sel, data)
		server_item = menu.data
		box = FXMessageBox.new(
			FXApp::instance, 
			$cfg.text.message.connection_error_title, 
			@data.server_item_to_warning[server_item],
			$cfg.icons.warning_big, MBOX_OK)
		box.create
		box.show(PLACEMENT_OWNER)
	end
	
	
	# Connect to all required events of an IRC_Server.
	def connect_to_server_events(server)
		server.connect_to_events(IRC_Server::ON_SERVER_REGISTERED, self)
		server.connect_to_events(IRC_Server::ON_CHANNEL_JOIN_SUCCESS, self)
		server.connect_to_events(IRC_Server::ON_SERVER_DISCONNECTED, self)
		server.connect_to_events(IRC_Server::ON_USER_KICK, self)
	end
	
	# Handles all callbacks from IRC_Server, XDCC_Announcement_Storage and XDCC_Download_Handler.
	def on_event(caller, event_type, args)
		@data.gui_mutex.synchronize do
			case event_type
			when IRC_Server::ON_SERVER_REGISTERED
				server_item = @data.irc_server_to_item[caller]
				return if !server_item
				@data.server_item_to_status[server_item] = CONNECTED
				server_item.closedIcon = $cfg.icons.connected
				server_item.openIcon = $cfg.icons.connected
				@gui.connections.recalc
				
			when IRC_Server::ON_SERVER_DISCONNECTED
				error_msg = args[0] || ""
				server_item = @data.irc_server_to_item[caller]
				return if !server_item
				# disconnected by the user, or forced disconnect?
				icon = $cfg.icons.disconnected
				unless @data.server_item_to_status[server_item] == DISCONNECTED
					@data.server_item_to_status[server_item] = CONNECTION_FAILED
					@data.server_item_to_warning[server_item] = $cfg.text.message.connection_error + ":\n" + error_msg
					icon = $cfg.icons.connection_failed
				else
					@data.server_item_to_status[server_item] = DISCONNECTED
				end
				server_item.closedIcon = icon
				server_item.openIcon = icon
				# set all channel items to disconnected
				server_item.each do |channel_item|
					channel_item.closedIcon = icon
					channel_item.openIcon = icon
				end
				@gui.connections.recalc
				
			when IRC_Server::ON_CHANNEL_JOIN_SUCCESS
				channel_name, channel_mode = args
				channel_name.downcase!
				server_item = @data.irc_server_to_item[caller]
				channel = @data.server_to_channels[server_item].detect { |channel| channel.text==channel_name }
				
				# Follow automatic channel forwards
				if !channel
					# create icon
					channel_name = "#" + channel_name unless channel_name[0] == ?#
					channel_name.downcase!
					server_item.expanded = true
					# check if channel already available
					return if @data.server_to_channels[server_item].detect { |channel_item| channel_item.text == channel_name }
					# create item
					channel = nil
					if FOXVERSION=="1.6"
						channel = @gui.connections.appendItem(server_item, channel_name, $cfg.icons.connecting, $cfg.icons.connecting)
					else
						channel = @gui.connections.addItemLast(server_item, channel_name, $cfg.icons.connecting, $cfg.icons.connecting)
					end
					@data.server_to_channels[server_item].push channel
					@gui.connections.sortChildItems(server_item)
				end
				channel.closedIcon = $cfg.icons.connected
				channel.openIcon = $cfg.icons.connected
				@gui.connections.recalc
			
			when XDCC_Announcement_Storage::ON_ANNOUNCEMENT_NEW
				ann = args[0]
				bot = ann.irc_user_bot.name
				
				# set slot representing icon
				if ann.ann_type == XDCC_Announcement::ANN_FULL
					icon = $cfg.icons.packet
					icon = $cfg.icons.free_slots if ann.openslot_cnt > 0
				else
					icon = $cfg.icons.slots_unknown
				end
				
				is_added = false
				match_data = @search_engine.get_match_data
				ann.packs.each do |pack|
					# create an unconnected item
					item = Packet_Item.new(nil, icon, bot, pack.name, pack.size)
					item.data = pack
					@data.allpack_to_item[pack] = item
					
					# item needs to be added to a list, before calling match()
					item.parent = @gui.packet_list
					if match?(item, match_data)
						item.show
						is_added = true
					end
				end
				if is_added
					update_search_status_text
					@gui.packet_list.sortItems
				end
				
			when XDCC_Announcement_Storage::ON_ANNOUNCEMENT_LOST
				ann = args[0]
				ann.packs.each do |pack|
					item = @data.allpack_to_item.delete(pack)
					item.parent = nil
				end
				update_search_status_text
				
			when XDCC_Download_Handler::ON_DOWNLOAD_STARTED
				item = @data.downloadpack_to_item[args[0]]
				item.fox_item.miniIcon = $cfg.icons.free_slots
				item[3] = $cfg.text.download_started
				@gui.active_list.sortItems
				
			when XDCC_Download_Handler::ON_DOWNLOAD_FINISHED
				pack = args[0]
				item = @data.downloadpack_to_item[pack]
				@gui.speed_widget.delete(item)
				item.parent = @gui.completed_list
				item.show
				item.fox_item.miniIcon = $cfg.icons.completed
				item[3] = $cfg.text.download_finished
				@gui.completed_list.sortItems
				# show "download finished" box
				Download_Finished_Box.new(@gui.main_window, item[1])
				
			when XDCC_Download_Handler::ON_MD5_STATUS
				pack, status = args
				item = @data.downloadpack_to_item[pack]
				item[3] = case status
				when XDCC_Download_Handler::MD5_DISABLED
					$cfg.text.md5.disabled
				when XDCC_Download_Handler::MD5_UNAVAILABLE
					$cfg.text.md5.unavailable
				when XDCC_Download_Handler::MD5_OK
					$cfg.text.md5.ok
				when XDCC_Download_Handler::MD5_FAILED
					$cfg.text.md5.failed
				end
				@gui.completed_list.sortItems
			
			when XDCC_Download_Handler::ON_DOWNLOAD_FAILED
				pack, error_msg = args
				item = @data.downloadpack_to_item[pack]
				@gui.speed_widget.delete(item)
				item.parent = @gui.error_list
				item.show
				item.fox_item.miniIcon = $cfg.icons.package_failed
				item[3] = error_msg
			
			when XDCC_Download_Handler::ON_DOWNLOAD_PROGRESS
				pack, percentage, received_bytes, speed  = args
				item = @data.downloadpack_to_item[pack]
				@gui.speed_widget[item] = speed
				item[3] = sprintf("%.1f%%", percentage)
				item[4] = sprintf("%.1fkb", speed)
				@gui.active_list.sortItems
				
			when XDCC_Download_Handler::ON_QUEUED_LOCALLY
				pack, queue_pos, queue_length = args
				if queue_length
					queue_length = queue_length.to_s
				else
					queue_length = "?"
				end
				item = @data.downloadpack_to_item[pack]
				item[3] = sprintf($cfg.text.queue_local + " %d/%s", queue_pos, queue_length)
				@gui.active_list.sortItems
				
			when XDCC_Download_Handler::ON_QUEUED_REMOTELY
				pack, queue_pos, queue_length = args
				if queue_length
					queue_length = queue_length.to_s
				else
					queue_length = "?"
				end
				item = @data.downloadpack_to_item[pack]
				return if !item
				item[3] = sprintf($cfg.text.queue_remote + " %d/%s", queue_pos, queue_length)
				@gui.active_list.sortItems
				
			when XDCC_Download_Handler::ON_PACK_REQUESTED
				pack = args[0]
				item = @data.downloadpack_to_item[pack]
				str = item[3]
				
				if str.include?($cfg.text.download_requesting)
					# animate with ... to visualize something is happening :-)
					if str[-3..-1] == "..."
						item[3] = $cfg.text.download_requesting
					else
						item[3] += "."
					end
				else
					item[3] = $cfg.text.download_requesting
				end
				@gui.active_list.sortItems
				
			when IRC_Server::ON_USER_KICK
				irc_user, channel_name, kick_msg = args
				if irc_user == caller.me
					server_item = @data.irc_server_to_item[caller]
					channel_item = @data.server_to_channels[server_item].detect { |channel_item| channel_item.text == channel_name }
					if channel_item
						channel_item.closedIcon = $cfg.icons.connection_failed
						channel_item.openIcon = $cfg.icons.connection_failed
					end
				end
			end
		end
	end
end
