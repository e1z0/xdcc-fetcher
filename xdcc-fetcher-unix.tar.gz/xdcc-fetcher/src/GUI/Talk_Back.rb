# Copyright (c) 2004, 2005 Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Martin Ankerl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

require 'fox'

include Fox

require 'src/Utilities/Globals'

# Unfortunately Talk_Back only works for email server that allow non-secure connections, 
# and therefore is useless. Let's wait until smtp supports everything requird.
class Talk_Back < FXDialogBox
	def Talk_Back.run(err)
		$main_window.hide if $main_window
		app = FXApp.instance || FXApp.new($cfg.talkback.name, $cfg.talkback.name)
		app.create
		main = $main_window || FXMainWindow.new(FXApp.instance, $cfg.talkback.name)
		main.hide
		puts err.backtrace
		tb = Talk_Back.new(app, err)
		tb.execute
		app.run
	end
	
	def initialize(app, err)
		super(app, $cfg.talkback.name, DECOR_ALL, 0, 0, 400, 400)		
		@err = err
		@time = Time.now
		build_controls
	end

	def create
		super
		if dialog == MBOX_CLICKED_OK
			show(PLACEMENT_SCREEN)
		else
			exit
		end
	end
	
	def build_controls
		FXVerticalFrame.new(self, LAYOUT_FILL_X|LAYOUT_FILL_Y) do |main|
			FXLabel.new(main, "1. Specify your email, if you want an response:", nil, LABEL_NORMAL)
			@addr = FXTextField.new(main, 1, nil, 0, TEXTFIELD_NORMAL|LAYOUT_FILL_X|FRAME_SUNKEN) do |addr|
				addr.text = "anonymous@unknown.com"
			end
			FXLabel.new(main, "2. If possible, describe how you got this crash:", nil, LABEL_NORMAL)
			FXHorizontalFrame.new(main, LAYOUT_FILL_X|LAYOUT_FILL_Y|FRAME_SUNKEN, 0,0,0,0, 0,0,0,0,0,0) do |textframe|
				@user_desc = FXText.new(textframe, nil, 0, TEXTFIELD_NORMAL|LAYOUT_FILL_X|LAYOUT_FILL_Y) do |user_desc|
					user_desc.text = "1. Steps to reproduce\n\n\n\n"
					user_desc.text += "2. Steps to reproduce\n\n\n\n"
					user_desc.text += "3. Steps to reproduce\n\n\n\n"
				end
			end
			
			FXLabel.new(main, "When you click 'Send', an email is sent to\nxdcctest@gmail.com that contains your specified\ninformation and a stack trace. No other private\ninformation is sent.", nil, JUSTIFY_LEFT|ICON_BEFORE_TEXT)
			
			FXHorizontalSeparator.new(main)
			
			FXHorizontalFrame.new(main, LAYOUT_FILL_X) do |buttonframe|
				@send_btn = FXButton.new(buttonframe, $cfg.text.submit, nil, nil, 0, BUTTON_NORMAL|LAYOUT_CENTER_X)
				@send_btn.connect(SEL_COMMAND) { on_cmd_send }
				@cancel_btn = FXButton.new(buttonframe, $cfg.text.cancel	, nil, nil, 0, BUTTON_NORMAL|LAYOUT_CENTER_X)
				@cancel_btn.connect(SEL_COMMAND) { exit }
			end
		end
		
	end
	
	def dialog
		FXMessageBox.error(self, MBOX_OK_CANCEL, $cfg.talkback.name, $cfg.text.talkback.preamble)
	end
	
	def on_cmd_send
		subject = "[BUG] #{$cfg.app.version}, Revision #{$cfg.app.revision}, #{@time}"
		text = @user_desc.text
		text += "\n\n-------------------\n\n"
		text += `ruby --version` + "\n"
		text += "FXRuby #{Fox.fxrubyversion}"
		text += "\n\n-------------------\n\n"
		text += "Version:  #{$cfg.app.version}\n"
		text += "Revision: #{$cfg.app.revision}\n\n"
		text += @err.message + "\n" + @err.backtrace.join("\n")
		
		msg = ["Subject: " + subject + "\n", "\n", text+"\n"]
		recipients = [ "martin.ankerl@fh-hagenberg.at" ] #"xdcctest@gmail.com" ]
		
		puts text
		
		Net::SMTP.enable_tls(OpenSSL::SSL::VERIFY_NONE)
		Net::SMTP.start("mailse.fh-hagenberg.at") do |smtp|
			smtp.sendmail(msg, @addr.text.strip, recipients)
		end
		exit
	end
end