# Copyright (c) 2004, 2005 Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Martin Ankerl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Speed_Widget is a widget to display the download speed. The widget shows the average 
# average download speed.
class Speed_Widget

	# Create a new widget in parent with given width. The specified block is used to convert an
	# integer value into a string that is used to display the current average speed. The widget
	# updates itself every 0.5 second.
	def initialize(parent, width, init_text, &proc) # :yields: current_speed
		@updateMutex = Mutex.new
		@val_to_str = proc
		@max = 10000
		@slowness = 0.95
		FXHorizontalFrame.new(parent, FRAME_SUNKEN|LAYOUT_FILL_Y, 0,0,0,0, 1,1,1,1,1,1) do |frame|
			@progress = FXProgressBar.new(frame, nil, 0, LAYOUT_FILL_Y|LAYOUT_FIX_WIDTH) do |progress|
				progress.width = width
				progress.total = @max
			end
			@label = FXLabel.new(frame, init_text, nil, JUSTIFY_CENTER_Y|JUSTIFY_RIGHT|LAYOUT_FIX_WIDTH) do |label|
				label.width = 60
			end
		end
		@highest_val = 0
		@value = 0.0
		@values = Hash.new
		
		@updater = Thread.new do
			loop do
				update
				sleep(0.1)
			end
		end
	end
	
	# Specify how slow adapting is, a value from 0 to 1.
	#  0.0: instantaneously 
	#  0.5: medium
	#  0.9: extremely slow
	def slowness=(slowness)
		@slowness = slowness
	end
	
	# The widget uses multiple sources for the average speed. All values specified here are summed
	# up.
	def []=(key, val)
		@values[key] = val
	end
	
	# Remove a source.
	def delete(key)
		@values.delete(key)
	end
	
	private
	
	# update is called every 0.1 second.
	def update
		@updateMutex.synchronize do 
			# sum up values
			new_value = 0
			@values.each_value do |val|
				new_value += val
			end
			# update top value
			@highest_val = new_value if (new_value > @highest_val)
			return if @highest_val == 0
			# exponentally adapt to new value
			last_value = @value
			@value = @value*@slowness + new_value*(1-@slowness)
			# nothing to do if value has not changed
			return if @value == last_value
			# calc + set progress bar size
			@progress.progress = (1.0 * @max / @highest_val * @value).to_i
			# set text
			@label.text = @val_to_str.call(new_value)
		end
	end
end