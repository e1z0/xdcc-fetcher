# Copyright (c) 2004, 2005 Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
# * Redistributions of source code must retain the above copyright notice, this list 
#   of conditions and the following disclaimer.
# * Redistributions in binary form must reproduce the above copyright notice, this list 
#   of conditions and the following disclaimer in the documentation and/or other materials 
#   provided with the distribution.
# * Neither the name of Martin Ankerl nor the names of its contributors may be used to 
#   endorse or promote products derived from this software without specific prior written 
#   permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Context_Menu is a more convenient way to use context menus. It allows the creation of states that enable/disable items.
class Context_Menu
	attr_accessor :data, :pane
	
	# Creates a new Context_Menu for given parent. If you provide a block, 
	# this code is called whenever the menu is shown.
	def initialize(parent, title="", icon=nil, &proc) # :yields: self, sender, sel, data
		@proc = proc
		@data = nil
		@menu_commands = Array.new
		@states = Hash.new
		@parent = parent
		@pane = FXMenuPane.new(parent)
		@title = FXMenuTitle.new(parent, title, icon, @pane)

		#@parent.connect(SEL_RIGHTBUTTONRELEASE, method(:on_right_click))
	end

	# Add an FXMenuSeparator separator.
	def add_separator
		FXMenuSeparator.new(@pane)
		@pane.recalc
	end

	# Add a new entry to the context menu. The supplied code is called
	# when this entry is activated.
	def add(text, icon=nil, &proc) # :yields: self, sender, sel, data
		cmd = FXMenuCommand.new(@pane, text, icon)
		@menu_commands.push cmd
		cmd.connect(SEL_COMMAND) { |sender, sel, data| proc.call(self, sender, sel, data) }
		@pane.recalc
		cmd
	end
	
	def add_check(text, checked=false, icon=nil, &proc)
		cmd = FXMenuCheck.new(@pane, text, icon)
		@menu_commands.push cmd
		cmd.check = checked
		cmd.connect(SEL_COMMAND) { |sender, sel, data| proc.call(self, sender, sel, data) }
		@pane.recalc
		cmd
	end
		
	def add_radio(text, checked=false, icon=nil, &proc)
		cmd = FXMenuRadio.new(@pane, text, icon)
		@menu_commands.push cmd
		cmd.check = checked
		cmd.connect(SEL_COMMAND) { |sender, sel, data| proc.call(self, sender, sel, data) }
		@pane.recalc
		cmd
	end
	
	# adds a subcontextmenu
	def add_submenu(text, menu, icon=nil)
		FXMenuCascade.new(@pane, text, icon, menu.pane)	
	end
	
	
	# Create a new state which can later be accessed using the key state_name.
	# For each menu entry, you need to specify if it should be enabled or disabled (true/false).
	def new_state(state_name, *args)
		raise "need #{@menu_commands.size} stati, but got #{args.size}" if @menu_commands.size != args.size
		@states[state_name] = args
	end

	# Loads a state which has previously been set using #new_state.
	def load_state(state_name)
		state = @states[state_name]
		state.each_index do |i|
			@menu_commands[i].enabled = state[i]
		end
	end

	# Shows the context menu.
	def execute(sender, sel, data)
		@proc.call(self, sender, sel, data) if @proc
		@pane.create
		@pane.popup(nil, data.root_x, data.root_y)
		@parent.app.runModalWhileShown(@pane)
	end
end
