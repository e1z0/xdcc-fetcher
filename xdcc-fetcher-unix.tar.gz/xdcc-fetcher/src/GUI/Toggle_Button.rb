# Copyright (c) 2004, 2005 Christoph Heindl and Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#      may be used to endorse or promote products derived from this software without specific 
#      prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# A button that uses the state (down, up) to display if it is enabled or not.
# the specified proc is executed 
class Toggle_Button

	# Creates a new toggle button. The specified block is called with the new toggle status whenever the button is clicked.
	def initialize(parent, icon, text, toggled, &proc) # :yields: new_toggle_status
		@btn = FXButton.new(parent, text, icon, nil, 0, FRAME_RAISED)
		@toggled = toggled
		@proc = proc
		@btn.connect(SEL_COMMAND) do |sender, sel, data|
			@toggled = !@toggled
			on_toggle(@toggled)
			@proc.call(@toggled) if @proc
		end
		on_toggle(@toggled)
	end
	
	# Check if the button is toggled (status down)
	def toggled?
		@toggled
	end
	
	private
	
	def on_toggle(status)
		if status
			@btn.state = STATE_DOWN
		else
			@btn.state = STATE_UP
		end
	end
end