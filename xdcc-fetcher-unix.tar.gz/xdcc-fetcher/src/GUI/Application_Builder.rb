# Copyright (c) 2004-2005 Christoph Heindl and Martin Ankerl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
# * Redistributions of source code must retain the above copyright notice, this list 
#   of conditions and the following disclaimer.
# * Redistributions in binary form must reproduce the above copyright notice, this list 
#   of conditions and the following disclaimer in the documentation and/or other materials 
#   provided with the distribution.
# * Neither the name of Christoph Heindl and Martin Ankerl nor the names of its contributors 
#   may be used to endorse or promote products derived from this software without specific 
#   prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

class Application_Builder
	def initialize(parent, gui, data, logic)
		@gui = gui
		@data = data
		@parent = parent
		@logic = logic
		build_menu(parent)
		FXVerticalFrame.new(parent , LAYOUT_FILL_X|LAYOUT_FILL_Y, 0,0,0,0, 0,0,0,0,0,0) do |base|
			build_main_frame(base) do |left_frame, right_frame, bottom_frame|
				build_connections(left_frame)
				build_search(right_frame)
				build_status(bottom_frame)
			end
			build_status_bar(base)
		end
		build_dialog_boxes(parent)
		# return created stuff
		@gui.close
	end
	
	# Build menu controls.
	def build_menu(parent)
		FXMenuBar.new(parent , LAYOUT_SIDE_TOP|LAYOUT_FILL_X) do |menu_bar|
			file = Context_Menu.new(menu_bar, $cfg.text.file)
			file.add($cfg.text.add_server, $cfg.icons.add) { |*args| @logic.on_add_server_click(*args) }
			file.add_separator
			file.add($cfg.text.quit, $cfg.icons.quit) { FXApp::instance.exit }
			
			options = Context_Menu.new(menu_bar, $cfg.text.options)
			
			# build languages
			languages = Context_Menu.new(@gui.main_window)
			lang_defs = Array.new
			$cfg.translations.attrs.each do |lang|
				lang_defs.push [$cfg.translations[lang].language_name, lang]
			end
			@gui.language_radios = Array.new
			lang_defs.sort.each do |name, lang|
				cmd = languages.add_radio(name, lang==$cfg.config.current_language) { |*args| @logic.on_language_change(lang, *args) }
				@gui.language_radios.push cmd
			end
			options.add_submenu($cfg.text.language, languages, $cfg.icons.translations)
			
			
			help = Context_Menu.new(menu_bar, $cfg.text.help)
			help.add($cfg.text.about, $cfg.icons.about) { @logic.on_about_click }
		end
	end
	
	# Build all dialog boxes.
	def build_dialog_boxes(parent)
		@gui.add_server_box = Dialog_Box.new(parent , $cfg.text.specify_server)

		@gui.add_server_box.add($cfg.text.server, FRAME_SUNKEN, nil, true, $cfg.text.enter_ip_or_domain)
		@gui.add_server_box.add($cfg.text.port, FRAME_SUNKEN|TEXTFIELD_INTEGER, $cfg.network.irc.default_port , true, $cfg.text.the_servers_port)
		@gui.add_server_box.add($cfg.text.nickname, FRAME_SUNKEN)
		@gui.add_server_box.add($cfg.text.password, TEXTFIELD_PASSWD|FRAME_SUNKEN, nil, false, nil)

		@gui.join_channel_box = Dialog_Box.new(parent, $cfg.text.add_channel_dialog)
		@gui.join_channel_box.add($cfg.text.channel, FRAME_SUNKEN, nil, true, $cfg.text.channel_name)
		@gui.join_channel_box.add($cfg.text.password, TEXTFIELD_PASSWD|FRAME_SUNKEN, nil, false, nil)				
	end
	
	# Build overall frame layout.
	def build_main_frame(parent) # :yields: left_frame, right_frame, bottom_frame
		left = right = bottom = nil
		# [---]
		FXSplitter.new(parent, SPLITTER_TRACKING|SPLITTER_VERTICAL|SPLITTER_REVERSED|LAYOUT_FILL_X|LAYOUT_FILL_Y) do |root_splitter|
			# [ | ]
			FXSplitter.new(root_splitter, SPLITTER_TRACKING|SPLITTER_HORIZONTAL|LAYOUT_FILL_X|LAYOUT_FILL_Y) do |splitter|
				left = FXVerticalFrame.new(splitter,
					FRAME_SUNKEN|LAYOUT_FILL_X|LAYOUT_FILL_Y, 0,0,$cfg.left.width,0, 0,0,0,0,0,0)
				right = FXVerticalFrame.new(splitter,
					FRAME_SUNKEN|LAYOUT_FILL_X|LAYOUT_FILL_Y, 0,0,0,0, 0,0,0,0,0,0)
			end
			bottom = FXVerticalFrame.new(root_splitter,
				LAYOUT_FILL_X, 0,0,0,$cfg.bottom.height, 0,0,0,0,0,0)
		end
		yield(left, right, bottom)
	end
	
	# Build the connections frame (on the left side).
	def build_connections(parent)
		FXLabel.new(parent, $cfg.text.connections, nil, JUSTIFY_CENTER_X|LAYOUT_FILL_X|FRAME_RAISED)
		if FOXVERSION=="1.0"
			@gui.connections = FXTreeList.new(parent, 20, nil,  0, 
				(FRAME_SUNKEN|
				TREELIST_SINGLESELECT|
				TREELIST_SHOWS_LINES|
				TREELIST_SHOWS_BOXES|
				TREELIST_ROOT_BOXES|
				LAYOUT_FILL_X|
				LAYOUT_FILL_Y))
		else
			@gui.connections = FXTreeList.new(parent, nil,  0, 
				(FRAME_SUNKEN|
				TREELIST_SINGLESELECT|
				TREELIST_SHOWS_LINES|
				TREELIST_SHOWS_BOXES|
				TREELIST_ROOT_BOXES|
				LAYOUT_FILL_X|
				LAYOUT_FILL_Y))
		end
		
		# empty area menu
		menu_empty_area = Context_Menu.new(@gui.connections)
		menu_empty_area.add($cfg.text.add_server, $cfg.icons.add) { |*args| @logic.on_add_server_click(*args) }

		# server menu
		menu_server = Context_Menu.new(@gui.connections) do |menu, sender, sel, data|
			# menu.data contains the server item
			# item's data is either CONNECTED, DISCONNECTED, CONNECTING
			menu.load_state(@data.server_item_to_status[menu.data])
		end
		menu_server.add($cfg.text.add_channel, $cfg.icons.add) { |*args| @logic.on_add_channel_click(*args) }
		menu_server.add_separator
		menu_server.add($cfg.text.connect, $cfg.icons.connected) { |*args| @logic.on_server_connect_click(*args) }
		menu_server.add($cfg.text.disconnect, $cfg.icons.disconnected)  { |*args| @logic.on_server_disconnect_click(*args) }
		menu_server.add($cfg.text.remove_server, $cfg.icons.remove) { |*args| @logic.on_remove_server_click(*args) }
		menu_server.add_separator
		menu_server.add($cfg.text.show_warning, $cfg.icons.warning) { |*args| @logic.on_show_warning(*args) }
		menu_server.new_state(Gui_Logic::CONNECTED, true, false, true, true, false)
		menu_server.new_state(Gui_Logic::CONNECTING, true, false, false, true, false)
		menu_server.new_state(Gui_Logic::DISCONNECTED, true, true, false, true, false)
		menu_server.new_state(Gui_Logic::CONNECTION_FAILED, true, true, false, true, true)

		# channel menu
		menu_channel = Context_Menu.new(@gui.connections)
		menu_channel.add($cfg.text.remove_channel, $cfg.icons.remove) { |*args| @logic.on_remove_channel_click(*args) }

		@gui.connections.init_clickedItem
		# which menu to show?
		@gui.connections.connect(SEL_RIGHTBUTTONRELEASE) do |sender, sel, data|
			#item = current_connections_item
			item = @gui.connections.clickedItem
			menu = nil
			if !item
				menu = menu_empty_area
			elsif item.parent
				menu = menu_channel
			else
				menu = menu_server
			end
			menu.data = item
			menu.execute(sender, sel, data)
		end
	end

	# Build search controls
	def build_search(parent)
		FXHorizontalFrame.new(parent, LAYOUT_FILL_X|FRAME_RAISED, 0,0,0,0, 0,0,0,0,0,0) do |search_frame|
			
			@gui.search_label = FXLabel.new(search_frame, $cfg.text.search, nil, LAYOUT_CENTER_Y)
			search = FXTextField.new(search_frame, 1, nil, 0, LAYOUT_FILL_Y|FRAME_SUNKEN|LAYOUT_FILL_X)
			search.connect(SEL_CHANGED) { @logic.on_search }
			@gui.search_field = Empty_Text_Field_Handler.new(search, $cfg.text.what_do_you_want_to_fetch_today)
			
			# create toggle buttons
			@gui.search_btn_free_slots = Toggle_Button.new(search_frame, $cfg.icons.free_slots , $cfg.text.free_slots, true)  { @logic.on_search }
			@gui.search_btn_slots_unknown = Toggle_Button.new(search_frame, $cfg.icons.slots_unknown, $cfg.text.slots_unknown, true)  { @logic.on_search }
			@gui.search_btn_packet = Toggle_Button.new(search_frame, $cfg.icons.packet, $cfg.text.no_free_slots, true)  { @logic.on_search }
			
			# icon -> button, required in match?()
			@data.packet_icon_to_toggle_btn[$cfg.icons.free_slots] = @gui.search_btn_free_slots
			@data.packet_icon_to_toggle_btn[$cfg.icons.slots_unknown] = @gui.search_btn_slots_unknown
			@data.packet_icon_to_toggle_btn[$cfg.icons.packet] = @gui.search_btn_packet			

			@gui.search_status_label = FXLabel.new(search_frame, $cfg.text.status_label_tooltip, nil, LAYOUT_CENTER_Y)
		end
		@gui.packet_list = Packet_List.new(@data, parent, nil, 0, $cfg.list.opts) do |packet_list|
			packet_list.add_header($cfg.text.bot, 70) { |x| x.downcase }
			packet_list.add_header($cfg.text.name, 250) { |x| x.downcase }
			packet_list.add_header($cfg.text.size, 70) { |x| -@logic.size_to_nr(x) }
		end
		@gui.packet_list.on_cmd_header(1)

		menu_packet_list = Context_Menu.new(@gui.packet_list) do |menu, sender, sel, data|
			menu.load_state(menu.data != nil)
		end
				
		menu_packet_list.add($cfg.text.download, $cfg.icons.add) { |*args| @logic.on_download_click(*args) }
		menu_packet_list.new_state(true, true)
		menu_packet_list.new_state(false, false)
		@gui.packet_list.connect(SEL_RIGHTBUTTONRELEASE) do |sender, sel, data|
			menu_packet_list.data = @logic.current_item(@gui.packet_list)
			menu_packet_list.execute(sender, sel, data)
		end
		@gui.packet_list.connect(SEL_DOUBLECLICKED) do |sender, sel, data|
			menu_packet_list.data = @logic.current_item(@gui.packet_list)
			@logic.on_download_click(menu_packet_list, sender, sel, data)
		end
	end

	# Build status controls (bottom frame).
	def build_status(parent)
		# active list
		active_btn = completed_btn = error_btn = nil
		FXHorizontalFrame.new(parent, LAYOUT_FILL_X, 0,0,0,0, 0,0,0,0,0,0) do |selection_frame|
			active_btn = FXButton.new(selection_frame, $cfg.text.active, $cfg.icons.active, nil, 0, ICON_BEFORE_TEXT|FRAME_RAISED|LAYOUT_FILL_X)
			completed_btn = FXButton.new(selection_frame, $cfg.text.completed, $cfg.icons.completed, nil, 0, ICON_BEFORE_TEXT|FRAME_RAISED|LAYOUT_FILL_X)
			error_btn = FXButton.new(selection_frame, $cfg.text.error, $cfg.icons.error, nil, 0, ICON_BEFORE_TEXT|FRAME_RAISED|LAYOUT_FILL_X)
		end
		@gui.active_list = Packet_List.new(@data, parent, nil, 0, $cfg.list.opts) do |active_list|
			active_list.add_header($cfg.text.bot, 70) { |x| x.downcase }
			active_list.add_header($cfg.text.name, 250) { |x| x.downcase }
			active_list.add_header($cfg.text.size, 70) { |x| -@logic.size_to_nr(x) }
			active_list.add_header($cfg.text.status, 130) { |x| -@logic.sortable_status(x) }
			active_list.add_header($cfg.text.speed, 60) { |x| x ? -x.to_f : 0.0  }
		end
		@gui.active_list.on_cmd_header(3)		
		menu_active_list = Context_Menu.new(@gui.active_list) do |menu, sender, sel, data|
			menu.load_state(menu.data != nil)
		end
		menu_active_list.add($cfg.text.cancel, $cfg.icons.cancel) { |*args| @logic.on_cancel_download_click(*args) }
		menu_active_list.new_state(true, true)
		menu_active_list.new_state(false, false)
		@gui.active_list.connect(SEL_RIGHTBUTTONRELEASE) do |sender, sel, data|
			menu_active_list.data = @logic.current_item(@gui.active_list)
			menu_active_list.execute(sender, sel, data)
		end
		
		# completed list
		@gui.completed_list = Packet_List.new(@data, parent, nil, 0, $cfg.list.opts) do |completed_list|
			completed_list.add_header($cfg.text.bot, 70) { |x| x.downcase }
			completed_list.add_header($cfg.text.name, 250) { |x| x.downcase }
			completed_list.add_header($cfg.text.size, 70) { |x| -@logic.size_to_nr(x) }
			completed_list.add_header($cfg.text.checksum, 100) { |x| @logic.sortable_md5_status(x) }
		end
		@gui.completed_list.on_cmd_header(1)
		
		menu_completed_list = Context_Menu.new(@gui.completed_list)
		menu_completed_list.add($cfg.text.clear_list, $cfg.icons.clear) { @logic.on_clear_completed_list }
		@gui.completed_list.connect(SEL_RIGHTBUTTONRELEASE) do |sender, sel, data|
			menu_completed_list.data = @logic.current_item(@gui.completed_list)
			menu_completed_list.execute(sender, sel, data)
		end
		
		# error list
		@gui.error_list = Packet_List.new(@data, parent, nil, 0, $cfg.list.opts) do |error_list|
			error_list.add_header($cfg.text.bot, 70) { |x| x.downcase }
			error_list.add_header($cfg.text.name, 250) { |x| x.downcase }
			error_list.add_header($cfg.text.size, 70) { |x| -@logic.size_to_nr(x) }
			error_list.add_header($cfg.text.status, 100) { |x| x }
		end
		@gui.error_list.on_cmd_header(1)
		
		menu_error_list = Context_Menu.new(@gui.error_list)
		menu_error_list.add($cfg.text.clear_list, $cfg.icons.clear) { @logic.on_clear_error_list }
		@gui.error_list.connect(SEL_RIGHTBUTTONRELEASE) do |sender, sel, data|
			menu_error_list.data = @logic.current_item(@gui.error_list)
			menu_error_list.execute(sender, sel, data)
		end
				
		# create beautiful "tabs"
		tab_data = {
			active_btn => @gui.active_list,
			completed_btn => @gui.completed_list,
			error_btn => @gui.error_list
		}
		tabs = Custom_Tabs.new(tab_data)
		tabs.show(active_btn)
	end
	
	# Build the bottom status bar
	def build_status_bar(parent)
		@gui.status_bar = FXStatusBar.new(parent, LAYOUT_SIDE_BOTTOM|LAYOUT_FILL_X|STATUSBAR_WITH_DRAGCORNER)
		@gui.speed_widget = Speed_Widget.new(@gui.status_bar, 200, $cfg.text.speed_widget_init) do |val|
			sprintf("%.1fkb", val)
		end
		@gui.speed_widget.slowness = 0.8
	end	
end
