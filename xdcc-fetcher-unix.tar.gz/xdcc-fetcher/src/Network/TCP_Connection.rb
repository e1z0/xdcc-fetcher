# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


require 'socket'
# Disable ruby's own resolver, seemed to cause serious troubles on some windowses.
#require 'resolv-replace'
require 'src/Utilities/Events.rb'
require 'timeout'

# Provides businesslogic for handling a TCP client connection.
# Supports text based and binary based connections through wrapping the actual receive 
# and send procedure.
class TCP_Connection
	include Event_Publisher
	
	attr_reader :address, :port
	attr_accessor :proc_recv, :proc_send

	
	# -- connectable events
	
	# On socket connection established. Args: none
	ON_CONNECTED = Event_Publisher.next_global_eventID
	# On socket connection closed remotely. Args: none
	ON_CLOSED = Event_Publisher.next_global_eventID
	# On socket error. Args: error message
	ON_ERROR = Event_Publisher.next_global_eventID
	# On data received. Args: data
	ON_DATA = Event_Publisher.next_global_eventID
	# All events packaged in one
	ON_ALL_EVENTS = ON_CONNECTED + ON_CLOSED + ON_DATA + ON_ERROR
	
	def initialize(proc_recv, proc_send)
		@proc_recv = proc_recv
		@proc_send = proc_send
		@socket = nil
		@recv_thread = nil
		init_events
	end
	
	# Open connection to the specified server and port
	def open(address, port)
		@address = address
		@port = port
		
		if !self.connected?
			# Spawn a thread responsible for handling initial connection
			# That way, the the main thread is not blocked if connection cannot be 
			# established
			connect_thread = Thread.new do
				# Lower priority of connect thread. This may help higher level applications to increase there response time
				Thread.current.priority = $cfg.network.tcp.connect_thread_priority
				if @address && @port
					begin
						timeout($cfg.network.tcp.connect_timeout) {
							@socket = TCPSocket.new(@address, @port)
						}
						self.fire_event(ON_CONNECTED)
						# Setup the required receive thread which reads from the connection
						@recv_thread = Thread.new do
							begin
								while data = self.proc_recv.call(@socket)
									self.fire_event(ON_DATA, data) unless data.length == 0
								end
							self.close
							self.fire_event(ON_CLOSED)
							rescue IOError, SystemCallError, SocketError => err
								self.fire_event(ON_ERROR, err.to_s)
							end
						end
					rescue TimeoutError => err
						self.fire_event(ON_ERROR, $cfg.text.network.tcp.err_con_timeout)
					rescue IOError, SystemCallError, SocketError => err
						self.close
						self.fire_event(ON_ERROR, err.to_s)
					end
				else
					self.fire_event(ON_ERROR, $cfg.text.network.tcp.err_con_no_remote)
				end
			end
		else
			# Already connected
			self.fire_event(ON_ERROR, $cfg.text.network.tcp.err_con_active)
		end
	end
	
	# Send data to socket
	def send(data)
		begin
			@proc_send.call(@socket, data) if self.connected?
		rescue Exception => err
			self.fire_event(ON_ERROR, err.to_s)
			self.close
		end
	end
	
	# Immediate shutdown the connection
	def close
		begin
			@socket.close
		rescue Exception
		end
	end
	
	# Wait for the connection to close
	def wait
		if self.connected?
			@recv_thread.join
		else
			self.fire_event(ON_ERROR, $cfg.text.network.tcp.err_con_closed)
		end
	end
	
	# Is connection established?
	def connected?
		@socket && !@socket.closed?
	end
		
	# Generate a line based TCPConnection object. That is, data is received
	# whenever \r\n is received.
	def TCP_Connection.text
		recv_proc = proc do |socket|
			data = socket.gets("\r\n")
		end
		
		send_proc = proc do |socket, data|
			socket.puts(data)
		end	
		TCP_Connection.new(recv_proc, send_proc)
	end
	
	# Generate a TCPConnection object, capable of handling binary data packets.
	def TCP_Connection.binary
		recv_proc = proc do |socket|
			data = socket.recv(16384)
			(data.length > 0) ? data : nil
		end
		
		send_proc = proc do |socket, data|
			socket.print(data)
		end
		TCP_Connection.new(recv_proc, send_proc)
	end
end



