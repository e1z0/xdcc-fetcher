# Copyright (c) 2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

require 'ipaddr'

# Extends the IPAddr class with ip address range tests. 
class IPAddr

	# Split ip address at each dot
	def split_at_dot(ip)
		a = Array.new
		ip.split(".") do |part|
			a << part
		end
	end
	
	# Determine if the ip address is within the specified ip address range
	# Example: "192.168.x.x" evals true for 192.168.0.0 to 192.168.255.255
	# Example: "10.0.10-20.x" evals true for 10.0.10.0 to 10.0.19.255
	def in_range?(ip_range)
		ret = true
		ip_parts = self.split_at_dot(self.to_s)
		range_parts = self.split_at_dot(ip_range)
		range_parts.each_with_index do |part, i|
			if (reg = part.match(/^\d+$/))
				# Is single ip address
				if reg[0] != ip_parts[i]
					ret = false
					break
				end
			elsif reg = part.match(/^(\d+)-(\d+)$/)
				ip_part = ip_parts[i].to_i
				if ip_part < reg[1].to_i || ip_part >= reg[2].to_i
					ret = false
					break
				end
			end
		end
		ret
	end
	
	# Determines if current ip address is routable over the internet or not
	def routable_address?
		return !self.in_range?("10.x.x.x") && 
			   !self.in_range?("172.16-32.x.x") &&
			   !self.in_range?("192.168.x.x") &&
			   !self.local_loopback?
	end
	
	# Determines if current ip address is representing a local loopback ip address
	def local_loopback?
		return self.in_range?("127.x.x.x")
	end	
end

