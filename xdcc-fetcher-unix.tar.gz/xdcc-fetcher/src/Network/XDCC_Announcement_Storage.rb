# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


require 'thread'
require 'src/Utilities/Events.rb'
require 'src/Network/IRC_Server.rb'
require 'src/Network/XDCC_Parser.rb'

class XDCC_Announcement_Storage
	include Event_Publisher
	
	# -- Connectable events
	
	# Whenever a new(unknown, updated) announcement is available. Args: xdcc_announcement
	ON_ANNOUNCEMENT_NEW = Event_Publisher.next_global_eventID
	# Whenever a known announcement is lost, due to user quit or announcement update. Args: xdcc_announcement
	ON_ANNOUNCEMENT_LOST = Event_Publisher.next_global_eventID
	
	# Initialize with the given XDCC_Parser
	def initialize(xdcc_parser)
		@mutex = Mutex.new
		@bot_announcement = Hash.new
		@irc_servers = Array.new
		@parser = xdcc_parser
		@parser.connect_to_events(XDCC_Parser::ON_ANNOUNCEMENT, self)
		self.init_events
	end
	
	# Clear up, prepare for deallocation
	def shutdown
		@parser.disconnect_from_events(XDCC_Parser::ON_ANNOUNCEMENT, self)
		self.shutdown_events
	end
	
	# Handle a XDCC_Announcement
	# Basically decides, if it is unknown or known and based on this, takes the appropriate actions
	def handle_announcement(ann)
		@mutex.synchronize do
			# Check if we've already subsribed at the irc_server the ann was broadcasted on
			if !@irc_servers.include?(ann.irc_user_bot.irc_server)
				@irc_servers.push(ann.irc_user_bot.irc_server)
				ann.irc_user_bot.irc_server.connect_to_events(IRC_Server::ON_USER_QUIT|
															  IRC_Server::ON_USER_PART|
															  IRC_Server::ON_USER_KICK|
															  IRC_Server::ON_SERVER_DISCONNECTED,
															  self)
			end
		
			# Check if it is an unknown bot
			if !@bot_announcement.include?(ann.irc_user_bot)
				self.handle_new_announcement(ann)
			else
				self.handle_existing_announcement(ann)
			end
		end
	end
	
	# Handles an unknown XDCC_Announcement.
	# Broadcasts an ON_ANNOUNCEMENT_NEW event
	def handle_new_announcement(ann)
		@bot_announcement[ann.irc_user_bot] = ann
		self.fire_event(ON_ANNOUNCEMENT_NEW, ann)
	end
	
	# Handles a known XDCC_Announcement.
	# An ON_ANNOUNCEMENT_UPDATE is being broadcasted if the XDCC_Announcement changed.
	def handle_existing_announcement(ann)
		# Check if announcement has updated
		if @bot_announcement[ann.irc_user_bot] != ann
			self.fire_event(ON_ANNOUNCEMENT_LOST, @bot_announcement[ann.irc_user_bot])
			self.fire_event(ON_ANNOUNCEMENT_NEW, ann)
			@bot_announcement[ann.irc_user_bot] = ann
		end
	end
	
	# Handles a user quit message.
	# A ON_ANNOUNCEMENT_LOST is thrown, if the user quitting used to offer XDCC_Packs.
	def handle_user_quit(irc_user)
		@mutex.synchronize do
			ann = @bot_announcement.delete(irc_user)
			self.fire_event(ON_ANNOUNCEMENT_LOST, ann) if ann
		end
	end
	
	# When disconnected from server, all announcements found on this server
	# are treated as lost. the server itself is not killed.
	def handle_server_disconnect(irc_server)
		@mutex.synchronize do
			@bot_announcement.delete_if do |bot, ann|
				ret = (bot.irc_server == irc_server)
				self.fire_event(ON_ANNOUNCEMENT_LOST, ann) if ret
				ret
			end
		end
	end
	
	# When a user is kicked from a certain channel. Possible announcements
	# belonging to that user are being treated as lost. If the user is
	# ourself, all announcements found on that channel are being treated as lost
	def handle_channel_left(irc_server, channelname, irc_user)
		if irc_server.me.has_name?(irc_user.name)
			# We have been forced to leave channel
			chan = channelname.downcase
			@mutex.synchronize do
				@bot_announcement.delete_if do |bot, ann|
					# Although announcement may be broadcasted in multiple channels,
					# we only check the first so far
					# TODO: check if announcement was broadcasted in other chans (we know)
					# too. If we are in such a chan, don't kill announcement
					ret = (ann.targets[0].downcase == chan)
					self.fire_event(ON_ANNOUNCEMENT_LOST, ann) if ret
					ret
				end
			end
		else
			# User (potential bot has been kicked)
			username = irc_user.name.downcase
			@mutex.synchronize do
				@bot_announcement.delete_if do |bot, ann|
					ret = (bot.name.downcase == username)
					self.fire_event(ON_ANNOUNCEMENT_LOST, ann) if ret
					ret
				end
			end	
		end
	end
	
	# Handle incoming events
	def on_event(caller, event, eventargs)
		case event
			when XDCC_Parser::ON_ANNOUNCEMENT
				self.handle_announcement(eventargs[0])
			
			when IRC_Server::ON_USER_QUIT 
				self.handle_user_quit(eventargs[0])
				
			when IRC_Server::ON_SERVER_DISCONNECTED
				self.handle_server_disconnect(caller)
				
			when IRC_Server::ON_USER_KICK, IRC_Server::ON_USER_PART
				self.handle_channel_left(caller, eventargs[1], eventargs[0])
		end
	end
end

