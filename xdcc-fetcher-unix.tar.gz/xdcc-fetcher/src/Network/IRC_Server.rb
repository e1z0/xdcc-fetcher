# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


require 'src/Network/TCP_Connection.rb'
require 'src/Network/IRC_Message.rb'
require 'src/Network/IRC_User.rb'
require 'src/Network/IRC_Server_Respond_Map.rb'
require 'src/Network/DCC_Parser.rb'
require 'src/Network/CTCP_Handler.rb'

# The IRC_Server class represents a connection to an irc server. It allows the caller to connect/disconnect to/from a
# server as well as register for various events. Administrative maintainance of connection is done automatically.
# The server also keeps a list of IRC_Users it encounters (on channel join, private message, etc..) up to date.
class IRC_Server
	include IRC_Server_Respond_Map, Event_Publisher
		
	# Corresponds to a irc_user object, which represents us. Nil before connection established
	attr_reader :me 
	# Password, if any, used for registration
	attr_reader :password
	# DCC parser responsible for recognizing initial dcc requests
	attr_reader :dcc_parser
	
	# -- Connectable Events
	
	# Whenever an irc message is received. Args: IRC_Message
	ON_IRC_MESSAGE = Event_Publisher.next_global_eventID
	
	# IRC registration with server complete. Args: none
	ON_SERVER_REGISTERED = Event_Publisher.next_global_eventID
	# When we quit from irc, or connection to server was lost. Args: errormessage or nil
	ON_SERVER_DISCONNECTED = Event_Publisher.next_global_eventID
	# When we connection to server has been established. Args: none
	ON_SERVER_CONNECTED = Event_Publisher.next_global_eventID

	# On user joined channel. Args: IRC_User, channel
	ON_USER_JOIN = Event_Publisher.next_global_eventID
	# On user left channel. Args: IRC_User, channel, partmessage[?]
	ON_USER_PART = Event_Publisher.next_global_eventID
	# Whenever someone is kicked from a channel. Args:  IRC_User, channel, kickmessage[?]
	ON_USER_KICK = Event_Publisher.next_global_eventID
	# On user quit. Args: IRC_User, quitmessage[?]
	ON_USER_QUIT = Event_Publisher.next_global_eventID
	# On user changed its nick. Args: updated IRC_User, old nick
	ON_USER_NICK = Event_Publisher.next_global_eventID
	# Whenever changing a nick failed. Args: nickname, errormessage
	ON_USER_NICK_ERROR = Event_Publisher.next_global_eventID
	# On user sent a message. Args: IRC_User, message, target[+], raw IRC_Message
	# This contains private messages and notices
	ON_USER_MESSAGE = Event_Publisher.next_global_eventID
	
	# On userlist of channel. Args: channel, [status, IRC_User][+]
	ON_CHANNEL_USER_LIST = Event_Publisher.next_global_eventID
	# On channel topic notification. Args: channelname, topic
	ON_CHANNEL_TOPIC = Event_Publisher.next_global_eventID
	
	# Whenever an unknown user appears. Args: IRC_User
	ON_USER_APPEAR_CUSTOM = Event_Publisher.next_global_eventID
	# Whenever a channel has been sucessfully joined by us. Args: channelname
	ON_CHANNEL_JOIN_SUCCESS = Event_Publisher.next_global_eventID
	# Whenever a channel join was unsuccessful. Args: channelname, errormessage
	ON_CHANNEL_JOIN_ERROR = Event_Publisher.next_global_eventID
	
	# All server side events packed in one
	ON_ALL_SERVER_EVENTS = ON_SERVER_REGISTERED|
						   ON_SERVER_DISCONNECTED|
						   ON_SERVER_CONNECTED|
						   ON_IRC_MESSAGE
												 
	
	# All user events packaged in one
	ON_ALL_USER_EVENTS = ON_USER_JOIN|
						  ON_USER_PART|
						  ON_USER_QUIT|
						  ON_USER_NICK|
						  ON_USER_KICK|
						  ON_USER_NICK_ERROR|
						  ON_USER_MESSAGE
											  
	# All channel events packaged in one
	ON_ALL_CHANNEL_EVENTS = ON_CHANNEL_USER_LIST|
							ON_CHANNEL_TOPIC

	# All custom events packaged in one
	ON_ALL_CUSTOM_EVENTS = ON_USER_APPEAR_CUSTOM|
						   ON_CHANNEL_JOIN_SUCCESS|
						   ON_CHANNEL_JOIN_ERROR
	
	# All events packaged in one
	ON_ALL_EVENTS = ON_ALL_SERVER_EVENTS|
					ON_ALL_USER_EVENTS|
					ON_ALL_CHANNEL_EVENTS|
					ON_ALL_CUSTOM_EVENTS
	
	def initialize
		@tcp_con = nil
		@registered = false
		@command_queue = Array.new
		@user_list = Hash.new
		@me = nil
		init_respond_map
		self.init_events
		@dcc_parser = DCC_Parser.new(self)
		@ctcp_handler = CTCP_Handler.new(self)
	end
	
	# -- Connection Management
	
	# Connect to specified server/port using the given user info
	def connect(server, port, nick, user, password=nil)
		if !self.connected?
			#command queue is only allowed during the phase of registration
			@command_queue.clear
			@user_list.clear
			@password = password
			@me = IRC_User.new(nick, self)
			@me.user = user
			@user_list[@me.name.downcase] = @me
			@tcp_con = TCP_Connection.text
			@tcp_con.connect_to_events(TCP_Connection::ON_ALL_EVENTS, self)
			@tcp_con.open(server, port)
		end
	end
	
	# Disconnect from server using the given quit message
	def disconnect(quitmessage="Using XDCC-Fetch")
		if self.connected?
			self.send(IRC_Message.new("QUIT", quitmessage))
			@tcp_con.close if @tcp_con
		end
	end
	
	# Send a IRC_Message to the server we are registered to.
	# If not yet registered, command is added to the command queue
	# and will be executed once we are registered
	def send(irc_msg)
		if self.registered?
			@tcp_con.send(irc_msg.to_s)
		else
			@command_queue.push(irc_msg)
		end
	end
	
	# -- Status queries
	
	# Are we connected yet
	def connected?
		@tcp_con && @tcp_con.connected?
	end
	
	# Was registration successful
	def registered?
		self.connected? && @registered
	end
	
	# -- Channel management methods
	
	def join(channel, password=nil)
		msg = IRC_Message.new("JOIN")
		msg.add_parameter(channel)
		msg.add_parameter(password) if password
		self.send(msg)
	end
	
	def part(channel)
		self.send(IRC_Message.new("PART", channel))
	end
	
	# -- User management methods
	
	# Update user_list by adding non-existant IRC_Users and/or
	# modifying existing ones
	def update_user_list(irc_msg)
		user = nil
		event = false
		if irc_msg.prefix?
			user = @user_list[irc_msg.name.downcase]
			if !user
				# new user detected
				user = IRC_User.new(irc_msg.name, self)
				@user_list[user.name.downcase] = user
				event = true
			end
			user.user = irc_msg.user if irc_msg.user
			user.host = irc_msg.host if irc_msg.host
			if event
				self.fire_event(ON_USER_APPEAR_CUSTOM, user)
			end
		end
		user
	end
	
	# Add user by name
	def add_user(name)
		user = nil
		user = @user_list[name.downcase]
		if !user
			# New user
			user = IRC_User.new(irc_msg.name, self)
			@user_list[name.downcase] = user
		end
		user
	end
	
	# Retrieve single user by given name
	def get_user_by_name(username)
		@user_list[username]
	end
	
	# Loop through all users and yield those users matching the given regexp
	def scan_users_by_name(regexp)
		@user_list.values.each do |user|
			if user.name =~ regexp
				yield user
			end
		end
	end
	
	# -- TCP_Connection notify methods
	
	def on_event(caller, event, eventargs)
		if caller == @tcp_con
			case event
				when TCP_Connection::ON_CONNECTED
					# Try registering with service, using the parameters given
					@tcp_con.send(IRC_Message.new("PASS", @password).to_s) if @password
					@tcp_con.send(IRC_Message.new("NICK", @me.name).to_s)
					@tcp_con.send(IRC_Message.new("USER", @me.user, "0", "*", "XDCC-Fetcher client").to_s)
					self.fire_event(ON_SERVER_CONNECTED)
				
				when TCP_Connection::ON_DATA
					msg = IRC_Message.parse(eventargs[0])
					# Find appropriate action for received data and respond appropriate
					# See IRC_Server_Respond_Map
					respond_to(msg)
					

				when TCP_Connection::ON_CLOSED
					@registered = false
					@tcp_con.disconnect_from_events(TCP_Connection::ON_ALL_EVENTS, self) if @tcp_con
					self.fire_event(ON_SERVER_DISCONNECTED, nil)
					
				when TCP_Connection::ON_ERROR
					@registered = false
					@tcp_con.disconnect_from_events(TCP_Connection::ON_ALL_EVENTS, self) if @tcp_con
					self.fire_event(ON_SERVER_DISCONNECTED, eventargs[0])
					
			end
		end
	end
end