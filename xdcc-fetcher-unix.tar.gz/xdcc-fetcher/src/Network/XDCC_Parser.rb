# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

require 'src/Utilities/Timer.rb'
require 'src/Network/XDCC_Announcement'
require 'src/Network/XDCC_Pack.rb'
require 'set'

# Used for parsing xdcc announcements. During parsing, special precautions have been set 
# in order to prevent endless parsing of single announcement. Detects full announcements and
# broken/minimal announcements.
class XDCC_Parser
	include Event_Publisher

	@@timer = Timer.new(3)

	# -- Connectable events
	
	# Whenever a XDCC_Announcement completed. Args: XDCC_Announcement
	ON_ANNOUNCEMENT = Event_Publisher.next_global_eventID

	def initialize(proc_parse_ann, proc_parse_pack)
		@unfinished_entities = Hash.new			# All currently unfinished announcements
		@finished_entities = Array.new
		@irc_servers = Array.new				# All irc_servers we are currently connected to
		@parse_ann = proc_parse_ann				# Parses the beginning of an annoucement
		@parse_pack = proc_parse_pack			# Parses a single offered pack
		@mutex_unfinished = Mutex.new
		@mutex_finished = Mutex.new
		@max_idle_running = 5
		self.init_events
		@@timer.connect_to_events(Timer::ON_TIMER, self)
	end
	
	# Prepare for deletion
	def shutdown
		@irc_servers.each do |server|
			self.detach_from_server(server)
		end
		@@timer.disconnect_from_events(Timer::ON_TIMER, self)
		@mutex_unfinished.sychronize do
			@unfinished_entities.clear
		end
		@mutex_finished.sychronize do
			@finished_entities.clear
		end
	end
	
	# Start tracking announcements on the given IRC_Server
	def attach_to_server(irc_server)
		if !@irc_servers.member?(irc_server)
			@irc_servers << irc_server
			irc_server.connect_to_events(IRC_Server::ON_USER_QUIT |
													 IRC_Server::ON_USER_MESSAGE|
													 IRC_Server::ON_SERVER_DISCONNECTED,
													 self)
		end
	end
	
	# Stop tracking announcements on the specified IRC_Server
	def detach_from_server(irc_server)
		server = @irc_servers.delete(irc_server)
		irc_server.disconnect_from_events(IRC_Server::ON_USER_QUIT |
													    IRC_Server::ON_USER_MESSAGE|
														IRC_Server::ON_SERVER_DISCONNECTED,
													    self) if irc_server
	end
	
	# A user has quit irc. Delete its announcements
	def user_quit(irc_user)
		@mutex_unfinished.synchronize do
			@unfinished_entities.delete(irc_user)
		end
	end
	
	# A user sent a message. Parse message.
	def user_message(irc_user, message, targets)
		@mutex_unfinished.synchronize do
			entity = @unfinished_entities[irc_user]
			if entity
				# An unfinished parsing entity was found
				pack = @parse_pack.call(irc_user, message)
				if pack
					entity.ann.packs << pack
					entity.last_update = Time.now
					entity.idle_running_cnt = 0
				elsif (ann = @parse_ann.call(irc_user, message, targets)) &&
					  (entity.ann.ann_type == XDCC_Announcement::ANN_MINIMAL)
					# Unfinished minimal/broken XDCC_Announcements are replaced if 
					# a full announcement starts while still parsing the unfinished
					# minimal/broken announcement.
					@unfinished_entities.delete(irc_user)
					entity = Parser_Entity.new
					entity.ann = ann
					entity.last_update = Time.now
					entity.idle_running_cnt = 0
					@unfinished_entities.store(irc_user, entity)
				else
					entity.idle_running_cnt += 1
					if entity.idle_running_cnt >  @max_idle_running
						@unfinished_entities.delete(irc_user)
					end
				end
			else
				# No unfinished parsing entity.
				ann = @parse_ann.call(irc_user, message, targets)
				if ann
					entity = Parser_Entity.new
					entity.ann = ann
					entity.last_update = Time.now
					entity.idle_running_cnt = 0
					@unfinished_entities.store(irc_user, entity)
				elsif pack = @parse_pack.call(irc_user, message)
					entity = Parser_Entity.new
					entity.ann = XDCC_Announcement.new(irc_user, XDCC_Announcement::ANN_MINIMAL)
					entity.ann.targets = targets
					entity.ann.packs << pack
					entity.last_update = Time.now
					entity.idle_running_cnt = 0
					@unfinished_entities.store(irc_user, entity)
				end
			end
			if entity && entity.ann.completed?
				# A full announcement has finished
				@unfinished_entities.delete(irc_user)
				@mutex_finished.synchronize do
					@finished_entities << entity
				end
			end
		end
	end
	
	def on_timer(timestamp)
		# Broadcast finished packs
		@mutex_finished.synchronize do
			@finished_entities.each do |entity|
				self.fire_event(ON_ANNOUNCEMENT, entity.ann)
			end
			@finished_entities.clear
		end
		# Kill broken announcements
		@mutex_unfinished.synchronize do
			@unfinished_entities.delete_if do |irc_user, entity|
				ret = (timestamp - entity.last_update) > 30
				if ret && entity.ann.ann_type == XDCC_Announcement::ANN_MINIMAL
					# More then 30 seconds have passed since last bot message
					# Treat broken announcement as completed
					@mutex_finished.synchronize do
						@finished_entities << entity
					end
				end
				ret
			end
		end
	end
	
	def server_disconnect(irc_server)
		@mutex_unfinished.synchronize do
			@unfinished_entities.delete_if do |irc_user, entity|
				irc_user.irc_server == irc_server
			end
		end
		@mutex_finished.synchronize do
			@finished_entities.delete_if do |entity|
				entity.ann.irc_user_bot.irc_server == irc_server
			end
		end
	end
		
	def on_event(caller, eventtype, eventargs)
		case eventtype
			when IRC_Server::ON_USER_QUIT
				self.user_quit(eventargs[0])
			
			when IRC_Server::ON_USER_MESSAGE
				self.user_message(eventargs[0], eventargs[1], eventargs[2])
			
			when IRC_Server::ON_SERVER_DISCONNECTED
				self.server_disconnect(caller)
					
			when Timer::ON_TIMER
				self.on_timer(eventargs[0])
				
			
		end
	end
	
	def XDCC_Parser.iroffer_parser
		# Parses the start of a full announcement
		proc_ann = proc do |irc_user, message, targets|
			if reg = $cfg.network.xdcc.offer_regexp.match(message)
				ann = XDCC_Announcement.new(irc_user)
				ann.pack_cnt = reg[1].to_i
				ann.openslot_cnt = reg[2].to_i
				ann.slot_cnt = reg[3].to_i
				ann.targets = targets
				# Try to fetch queue info
				if queue_info = $cfg.network.xdcc.queue_regexp.match(message)
					ann.openqueue_cnt = queue_info[1].to_i
					ann.queue_cnt = queue_info[2].to_i
				end
				ann
			else
				nil
			end
		end
		
		# Parses a single pack within a full announcement
		proc_pack = proc do |irc_user, message|
			# Example: \002#1 \002 0x [123K] iroffer1.3.b09.tgz
			if reg = $cfg.network.xdcc.pack_regexp.match(message)
				pack = XDCC_Pack.new(irc_user)
				pack.pack_nr = reg[1].to_i;
				pack.download_cnt = reg[2].to_i;
				pack.size = reg[3];
				# Delete all style and/or color codes in pack name and leading/trailing spaces afterwards
				pack.name = IRC_Message.delete_spaces(IRC_Message.delete_control_codes(reg[4]))
				pack
			else
				nil
			end
		end
		XDCC_Parser.new(proc_ann, proc_pack)
	end
end

# Structure used while parsing an announcement
class Parser_Entity
	attr_accessor :ann
	attr_accessor :last_update
	attr_accessor :idle_running_cnt
end