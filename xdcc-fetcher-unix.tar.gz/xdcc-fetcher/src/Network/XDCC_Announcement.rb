# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


require 'src/Network/XDCC_Pack.rb'
require 'src/Network/IRC_Message.rb'

# An XDCC_Announcement represents an complete offering of an xdcc bot. This includes info about the current bot status as
# well as the offered packs.
class XDCC_Announcement
	
	# The irc_user offering
	attr_reader :irc_user_bot
	#nr of packs offered, nr of available slots, nr of slots open and the targets this announcement was found at
	# Nr of packs in announcement
	attr_accessor :pack_cnt 
	# Total number of slots
	attr_accessor :slot_cnt
	# Number of slots available
	attr_accessor :openslot_cnt 
	# Total number of queue slots
	attr_accessor :queue_cnt  
	# Number of open queue positions
	attr_accessor :openqueue_cnt
	# Array of channels or nicknames, this announcement was sent to
	attr_accessor :targets
	# Type of announcement (FULL or MEDIUM)
	attr_reader :ann_type
	# Array of XDCC_Packs belonging to this announcement
	attr_reader :packs
	
	# -- Constants
	ANN_FULL = 0
	ANN_MINIMAL = 1
	
	# Initialize with the bot which offers
	def initialize(irc_user_bot, type=ANN_FULL)
		@pack_cnt = -1
		@irc_user_bot = irc_user_bot
		@packs = Array.new
		@openslot_cnt = -1
		@slot_cnt = -1
		@queue_cnt = -1
		@openqueue_cnt = -1
		@ann_type = type
	end
	
	# Has parsing completed
	def completed?
		@packs.length == @pack_cnt
	end
	
	# Does this announcement contain queue information
	def has_queue_info?
		@queue_cnt != -1
	end
	
	# Returns a human readable representation of this announcement as string
	def to_s
		s  = "XDCC_Announcement: #{@irc_user_bot.name} | nr of packs: #{@pack_cnt} | open slots: #{@openslot_cnt}/#{@slot_cnt} | queue: #{@openqueue_cnt}/#{@queue_cnt}\r\n"
		@packs.each do |pack|
			s += "#{pack}\r\n"
		end
		s
	end
	
	# Returns a xdcc representation of this announcement as array of irc_messages.
	# If channel is not given, the channelname is taken from the targets.
	def to_irc(channel=nil)
		channel = @targets[0] unless channel
		a = []
		a << IRC_Message.new("PRIVMSG", channel, "\002**\002 #{@pack_cnt} packs \002\002  #{@openslot_cnt} of #{@slot_cnt} slots open")
		a << IRC_Message.new("PRIVMSG", channel, "\002**\002 Bandwidth usage ...")
		a << IRC_Message.new("PRIVMSG", channel, "\002**\002 To request a file, type \"/msg ....")
		@packs.each do |pack|
			a << pack.to_irc(channel)
		end
		a << IRC_Message.new("PRIVMSG", channel, "Total Offered: 1.1 MB  Total Transferred: 2.13 MB")
	end
	
	# Determines equality of this xdcc_announcement and the given xdcc_announcement.
	def ==(ann)
		@irc_user_bot == ann.irc_user_bot &&
		@pack_cnt == ann.pack_cnt &&
		@slot_cnt == ann.pack_cnt &&
		@openslot_cnt == ann.openslot_cnt &&
		@packs == ann.packs
	end
end

#<mybotDCC> ** 4 packs **  20 of 20 slots open, Record: 3543.1KB/s
#<mybotDCC> ** Bandwidth Usage ** Current: 0.0KB/s, Record: 9.5KB/s
#<mybotDCC> ** To request a file, type "/msg mybotDCC xdcc send #x" **
#<mybotDCC> ** To request details, type "/msg mybotDCC xdcc info #x" **
#<mybotDCC> #1  2x [1.0M] Setup-NettalkIRCD.exe
#<mybotDCC> #2  1x [ 93K] XDCC-FetchGUI-nightly.zip
#<mybotDCC> #3  1x [ <1K] wscite162.zip
#<mybotDCC> #4  0x [ <1K] sometext.txt
#<mybotDCC> Total Offered: 1.1 MB  Total Transferred: 2.13 MB