# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

require 'src/Network/IRC_Message.rb'

# An XDCC_Pack represents a file to download in the XDCC pseudo protocol.
class XDCC_Pack
	# Bot, which offered pack
	attr_reader :irc_user_bot
	# Pack number, number of downloads, size, and pack name
	attr_accessor :pack_nr, :download_cnt, :size, :name

	# Initialize with the bot, which offers the pack, irc_server the bot is on
	def initialize(irc_user_bot)
		@irc_user_bot = irc_user_bot
	end

	# Returns a human readable representation of this pack as string
	def to_s
		"#{@pack_nr} | #{@download_cnt} | #{@size} | #{@name}"
	end
	
	# Returns a xdcc representation of this pack as an IRC_Message.
	# Channel is the target channel
	def to_irc(channel)
		IRC_Message.new("PRIVMSG", channel, "\002##{@pack_nr} \002 #{@download_cnt}x [#{@size}] #{@name}")
	end
	
	# Equality based on irc_bot, pack number and pack name
	# Download count is not included
	def ==(pack)
		return false unless pack
		@irc_user_bot == pack.irc_user_bot &&
		@pack_nr == pack.pack_nr &&
		@name == pack.name
	end
end