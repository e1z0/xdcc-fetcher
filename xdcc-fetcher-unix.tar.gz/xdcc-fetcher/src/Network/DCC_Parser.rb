# Copyright (c) 2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

require 'src/Network/IPAddr_Ext'

DCCAddress_Info = Struct.new("DCCAddress_Info", :address, :port)
DCCSEND_Info = Struct.new("DCCSEND_Info", :irc_user, :filename, :filesize, :dccaddress_info)

# Listens for incoming dcc sends and forwards
# them to its listeners
class DCC_Parser
	include Event_Publisher
	
	# -- Connectable events
	
	# User is offering a file. Args: DCCSEND_Info
	ON_DCC_SEND = Event_Publisher.next_global_eventID
	
	def initialize(irc_server)
		@irc_server = irc_server
		@irc_server.connect_to_events(IRC_Server::ON_USER_MESSAGE, self)
		self.init_events
	end
	
	def on_event(caller, eventtype, eventargs)
		case(eventtype)
			when IRC_Server::ON_USER_MESSAGE
				irc_user, message, targets, irc_msg = eventargs
				if irc_msg.ctcp_command? && @irc_server.me.has_name?(targets[0])
					# See if it is a dcc send
					if dcc = $cfg.network.dcc.send_regexp.match(message)
						# User is offerng a file
						# Try converting the given address info
						begin
							ipaddy = IPAddr.new_ntoh([dcc[2].to_i].pack("N"))
						rescue Exception 
							ipaddy = nil
						end
						addr = DCCAddress_Info.new(ipaddy, dcc[3].to_i)
						# Sanity check filename for invalid characters
						filename = dcc[1].gsub(/\/{1,}|\\{1,}|\.{2,}/, "")
						# Build DCCSEND_Info
						info = DCCSEND_Info.new(irc_user, filename, dcc[4].to_i, addr)
						self.fire_event(ON_DCC_SEND, info)
					end
				end
				
		end
	end
end