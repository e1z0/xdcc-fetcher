# Copyright (c) 2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# Parses extended ctcp queries and response appropriately if allowed to.
# Queries by the user itself (commands) are not supported (why should they?)
# as of now.
class CTCP_Handler

	def initialize(irc_server)
		@irc_server = irc_server
		@irc_server.connect_to_events(IRC_Server::ON_USER_MESSAGE, self)
	end
	
	def shutdown
		@irc_server.disconnect_from_events(IRC_Server::ON_USER_MESSAGE, self)
	end
	
	def on_event(irc_server, eventtype, eventargs)
		irc_user, message, targets, irc_msg = eventargs
		if (@irc_server.me.has_name?(targets[0]))
			if irc_msg.ctcp_command?
				return unless $cfg.network.ctcp.enable_replies
				case (irc_msg.parameters[-1])
					when "VERSION"
						irc_user.notice("\001VERSION #{$cfg.app.name}:#{$cfg.app.revision}:#{RUBY_PLATFORM}\001")
					when "SOURCE"
						irc_user.notice("\001SOURCE #{$cfg.app.url}::\001")
						irc_user.notice("\001SOURCE\001")
					when "PING"
						# Just sent back received string
						irc_user.notice(message)
					when "TIME"
						irc_user.notice("\001#{Time.now}\001")
					when "USERINFO"
						irc_user.notice("\001USERINFO :no way\001")
				end	
			end
		end
	end
end