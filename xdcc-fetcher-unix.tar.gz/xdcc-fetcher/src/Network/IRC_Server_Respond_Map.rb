# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


# The respond map is used within the context of the IRC_Server in order to react 
# appropriate to the received command/query. The first array element has to be successfully
# matched (regexp) against the IRC_Message.command in order to execute the proc object, 
# which equals the second array element
module IRC_Server_Respond_Map
	def init_respond_map
		@respond_map = [
			
			# -- misc
			
			# Any irc message
			# Action: forward message to listeners
			[
				/.*/,
				proc do |irc_msg|
					self.fire_event(IRC_Server::ON_IRC_MESSAGE, irc_msg)
				end
			],
		
			# -- service messages
			
			# PING
			# Action: send PONG to server
			[
				/PING/i,
				proc do |irc_msg|
					# Do not enqueue message if not yet registered.
					# Some servers do send a PING message as part of registration process.
					@tcp_con.send(IRC_Message.new("PONG", irc_msg.parameters[0]).to_s)
				end
			],
			
			# -- channel management
			
			# RPL_NAMREPLY
			# Action: extract usernames and stati, forward to listeners, update user_list
			[
				/353/, 
				proc do |irc_msg| 
					channel = irc_msg.parameters[2]
					users = irc_msg.parameters[3].scan(/([@+])?(\S+)/)
					channel_users = []
					# Store new users in irc_server user list
					users.each do |user|
						@user_list[user[1]] ||= IRC_User.new(user[1], self)
						channel_users.push([user[0], @user_list[user[1]]])
					end
					self.fire_event(IRC_Server::ON_CHANNEL_USER_LIST, channel, channel_users)
				end
			],
			
			# RPL_ENDOFNAMES
			# Action: trigger join channel success
			[
				/366/,
				proc do |irc_msg|
					self.fire_event(IRC_Server::ON_CHANNEL_JOIN_SUCCESS, irc_msg.parameters[1])
				end
			],
			
			# Error messages when joining a channel
			#ERR_BANNEDFROMCHAN
            #ERR_INVITEONLYCHAN              ERR_BADCHANNELKEY
            #ERR_CHANNELISFULL               ERR_BADCHANMASK
            #ERR_NOSUCHCHANNEL            ERR_TOOMANYCHANNELS
			[
				/474|473|475|471|476|403|405/,
				proc do |irc_msg|
					self.fire_event(IRC_Server::ON_CHANNEL_JOIN_ERROR, irc_msg.parameters[1], irc_msg.parameters[2])
				end
			],
			
			# KICK
			# Action: Inform listeners
			[
				/KICK/,
				proc do |irc_msg|
					irc_user = @user_list[irc_msg.parameters[1]]
					if (irc_user)
						self.fire_event(IRC_Server::ON_USER_KICK, irc_user, irc_msg.parameters[0], irc_msg.parameters[2])
					end
				end
			],
			
			# -- user management
			
			# JOIN
			# Action: Update user_list, inform listeners
			[
				/JOIN/i,
				proc do |irc_msg|
					user = self.update_user_list(irc_msg)
					self.fire_event(IRC_Server::ON_USER_JOIN, user, irc_msg.parameters[0])
				end
			],
			
			# PART
			# Action: update user_list, inform listeners
			[
				/PART/i,
				proc do |irc_msg|
					user = self.update_user_list(irc_msg)
					self.fire_event(
							IRC_Server::ON_USER_PART, 
							user,
							irc_msg.parameters[0],
							irc_msg.parameters[1])
				end
			],
			
			# NICK
			# Action: update user_list, inform listeners
			[
				/NICK/i,
				proc do |irc_msg|
					# Get user from user_list, possibly update data
					user = self.update_user_list(irc_msg)
					# Delete old user
					new_user = @user_list.delete(user.name.downcase)
					new_user.name = irc_msg.parameters[0]
					@user_list[new_user.name.downcase] = new_user
					self.fire_event(
							IRC_Server::ON_USER_NICK, 
							new_user,
							user.name)
				end
			],
			
			# NICK errors
			# ERR_NONICKNAMEGIVEN
			# ERR_ERRONEUSNICKNAME (invalid nickname)
            # ERR_NICKNAMEINUSE               
			# ERR_NICKCOLLISION
			[
				/431|432|433|436/,
				proc do |irc_msg|
					self.fire_event(IRC_Server::ON_USER_NICK_ERROR, irc_msg.parameters[1], irc_msg.parameters[2])
				end
			],


			
			# QUIT
			# Action: update user_list and inform listeners
			[
				/QUIT/i,
				proc do |irc_msg|
					user = @user_list.delete(irc_msg.name)
					if user
						self.fire_event(IRC_Server::ON_USER_QUIT, user, irc_msg.parameters[0])
					end
				end
			],
			
			# PRIVMSG && NOTICE
			# Action: inform listeners
			[
				/PRIVMSG|NOTICE/i,
				proc do |irc_msg|
					user = @user_list[irc_msg.name]
					if !user
						# private message from unknown user
						user = IRC_User.new(irc_msg.name, self)
						user.user = irc_msg.user
						user.host = irc_msg.host
						@user_list[user.name] = user
					end
					msg = irc_msg.parameters[-1]
					targets = irc_msg.parameters[0..-2]
					self.fire_event(IRC_Server::ON_USER_MESSAGE, user, msg, targets, irc_msg)
				end
			],
			
			# -- others
			
			# RPL_WELCOME
			# Action: mark irc_server registered and inform listeners. Send queued commands
			[
				/001/, 
				proc do |irc_msg|
					@registered = true
					self.fire_event(IRC_Server::ON_SERVER_REGISTERED)
					@command_queue.each do |cmd|
						self.send(cmd)
					end
					@command_queue.clear
				end
			]
		]
	end

	def respond_to(msg)
		@respond_map.each do |response|
			response[1].call(msg)  if msg.command =~ response[0]
		end
	end
	
end