# Copyright (c) 2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

DCC_Resume_Verification = Struct.new("DCC_Resume_Verification", 
									 :verified, 
									 :bytes_total,
									 :bytes_mine,
									 :bytes_their)
						  
DCC_File_Info = Struct.new("DCC_File_Info",
						   :status,					# Status of DCC
						   :irc_user,				# Remote irc user
						   :address,				# Remote address and port
						   :file,					# File handle
						   :joined_filename,		# path to file
						   :filename,				# filename originally sent by user
						   :md5,					# MD5 checksom of file
						   :verification,			# DCC_Resume_Verification struct
						   :skip_download,			# Should this download be skipped
						   :skip_status,			# Whats the status to be broadcasted after skip succeeds
						   :skip_reason,			# Whats the message to be broadcasted after skip succeeds
						   :bytes_total,			# Total number of bytes to receive
						   :bytes_received,			# Number of bytes received so far
						   :progress_timestamp,		# Last progress timestamp
						   :progress_bytes)			# Number of bytes since last progress event
						   
						  
# Handles dcc file transactions  
class DCC_File
	include Event_Publisher
	
	# -- Connectable events
	
	# Connection to remote dcc host successful. Args: none
	ON_DCC_ESTABLISHED = Event_Publisher.next_global_eventID
	# Transfer complete. Args: md5 checksum or nil
	ON_DCC_COMPLETED = Event_Publisher.next_global_eventID
	# Download/upload progress. 
	# Percent completed, nr of bytes received/sent, nr of kilo bytes per second 
	ON_DCC_PROGRESS = Event_Publisher.next_global_eventID
	# DCC error. Args: errormessage
	ON_DCC_ERROR = Event_Publisher.next_global_eventID
	
	ON_ALL_EVENTS = ON_DCC_ESTABLISHED|
					ON_DCC_COMPLETED|
					ON_DCC_PROGRESS|
					ON_DCC_ERROR

	
	def initialize()
		@tcp_con = TCP_Connection.binary
		@tcp_con.connect_to_events(TCP_Connection::ON_ALL_EVENTS, self)
		self.init_events
	end
	
	# Try to download using the given info.
	# Resumes the download if required
	def get(info, path)
		# Init some variables
		@info = DCC_File_Info.new(-1,
								  info.irc_user,
								  info.dccaddress_info,
								  nil,
								  "",
								  nil,
								  nil,
								  DCC_Resume_Verification.new(false, 0, "", ""),
								  false,
								  ON_DCC_ERROR,
								  "",
								  0,
								  0,
								  nil,
								  0)
								  
		# Check for correct tcp info
		if !@info.address.address || !@info.address.port
			@info.status = ON_DCC_ERROR
			self.fire_event(ON_DCC_ERROR, $cfg.text.network.tcp.err_invalid_address)
			return
		end
		
		# Check for not routable addresses if required
		if $cfg.network.dcc.block_nonroutable_addresses && !@info.address.address.routable_address?
			@info.status = ON_DCC_ERROR
			self.fire_event(ON_DCC_ERROR, $cfg.text.network.ip.err_notroutable_ip + " (#{@info.address.address.to_s})")
			return
		end
		
		# See if destination directory exists
		if !path || !File.exist?(path)
			@info.status = ON_DCC_ERROR
			self.fire_event(ON_DCC_ERROR, $cfg.text.network.dcc.err_dir_notexist)
			return
		end
		@info.joined_filename = File.join(path, info.filename)
		@info.bytes_total = info.filesize
		if File.exist?(@info.joined_filename)
			self.resume
		else
			# No resume required.
			# Init md5 if required and open connection
			@info.verification.verified = true
			@info.md5 = Digest::MD5.new if $cfg.network.xdcc.enable_md5
			@tcp_con.open(@info.address.address.to_s, @info.address.port)
		end
	end
	
	# Resume a partially downloaded file
	def resume
		# See if file is writeable
		if !File.writable?(@info.joined_filename)
			@info.status = ON_DCC_ERROR
			self.fire_event(ON_DCC_ERROR, $cfg.text.network.dcc.err_file_permission)
			return
		end
		# As of now, no md5 checksum will be calculated for resumed packs in order to not
		# slow down everything only due to md5 checksum calculation for the received data
		local_filesize = File.size(@info.joined_filename)
		
		# Initialize verification
		if $cfg.network.dcc.enable_verification
			@info.verification.verified = false
			@info.verification.bytes_total = (local_filesize > $cfg.network.dcc.verification_bytes) ? $cfg.network.dcc.verification_bytes : local_filesize
		else
			# Verification disabled
			@info.verification.verified = true 
			@info.verification.bytes_total = 0
		end
		@info.bytes_received = local_filesize - @info.verification.bytes_total
		if @info.bytes_received < @info.bytes_total
			# Ask for DCC RESUME
			@info.irc_user.irc_server.connect_to_events(IRC_Server::ON_USER_MESSAGE, self)
			@info.irc_user.send("\001DCC RESUME #{@info.filename} #{@info.address.port} #{@info.bytes_received}\001")
		elsif @info.bytes_received == @info.bytes_total
			# Pack already received. At least filesize tells us so. We therefore download a single byte from bot in 
			# order to terminate the connection fast and make it available for other packs.
			# This is not hack, well to be honest it is, but it is necessary due to dcc protocol limitations.
			@info.verification.verified = true
			@info.skip_download = true
			@info.skip_status = ON_DCC_COMPLETED
			@info.skip_reason = ""
			@tcp_con.open(@info.address.address.to_s, @info.address.port)
		else
			@info.verification.verified = true
			@info.skip_download = true
			@info.skip_status = ON_DCC_ERROR
			@info.skip_reason = $cfg.text.network.dcc.err_filesize_differ
			@tcp_con.open(@info.address.address.to_s, @info.address.port)
		end
	end
	
	# Close current transfer if active
	def close
		if @info
			@info.status = ON_DCC_ERROR
			begin
				@tcp_con.close if @tcp_con.connected?
				@info.file.close if @info.file && !@info.file.closed?
			rescue Exception
			end
		end
	end
	
	def on_event(caller, event, eventargs)
		case event
			when IRC_Server::ON_USER_MESSAGE
				return if @info.status == ON_DCC_ERROR
				irc_user, message, targets, irc_msg = eventargs
				# Check for private bot message
				irc_server = @info.irc_user.irc_server
				if ((@info.irc_user != irc_user) || !irc_server.me.has_name?(targets[0]))
					return
				end
				if irc_msg.ctcp_command?
					if dcc = $cfg.network.dcc.accept_regexp.match(message)
						irc_server.disconnect_from_events(IRC_Server::ON_USER_MESSAGE, self)
						# DCC Resume available, connect
						@tcp_con.open(@info.address.address.to_s, @info.address.port)
					end
				end
				
			when TCP_Connection::ON_CONNECTED
				if !@info.skip_download
					# Open file (use binary mode windows platforms), append if file exists
					begin
						@info.file = File.new(@info.joined_filename, "a+b")
					rescue Errno::EACCESS
						@info.status = ON_DCC_ERROR
						self.fire_event(ON_DCC_ERROR, $cfg.text.network.dcc.err_file_permission)
						@tcp_con.close
						return
					end
					if !@info.verification.verified
						@info.file.seek(-@info.verification.bytes_total, IO::SEEK_END)
						@info.verification.bytes_mine << @info.file.read
					else
						@info.file.seek(0, IO::SEEK_END)
					end
					# Read verification bytes_mine
					@info.file.sync = true
					# Set internal stati and trigger event
					@info.progress_timestamp = Time.now
					@info.progress_bytes = 0
					@info.status = ON_DCC_ESTABLISHED
					self.fire_event(ON_DCC_ESTABLISHED)
				else
					if @info.skip_status == ON_DCC_COMPLETED
						@info.status = ON_DCC_COMPLETED
						self.fire_event(ON_DCC_COMPLETED, nil)
					else
						@info.status = ON_DCC_ERROR
						self.fire_event(ON_DCC_ERROR, @info.skip_reason)
					end
					@tcp_con.close
				end
			
			when TCP_Connection::ON_CLOSED
				@tcp_con.close if @tcp_con.connected?
				@info.file.close if @info.file && !@info.file.closed?
				if @info.bytes_received != @info.bytes_total
					if !@info.status == ON_DCC_ERROR
						# No other code has yet triggered a download failed event
						@info.status = ON_DCC_ERROR
						self.fire_event(ON_DCC_ERROR, $cfg.text.network.xdcc.err_con_closed)
					end
				else
					@info.status = ON_DCC_COMPLETED
					self.fire_event(ON_DCC_COMPLETED, @info.md5)
				end
				
			when TCP_Connection::ON_ERROR
				# See if some other code has already triggered a download failed
				if @info.status != ON_DCC_ERROR && @info.status != ON_DCC_COMPLETED
					@tcp_con.close if @tcp_con.connected?
					@info.file.close if @info.file && !@info.file.closed?
					@info.status = ON_DCC_ERROR
					self.fire_event(ON_DCC_ERROR, eventargs[0])
				end
				
			when TCP_Connection::ON_DATA
				if (@info.skip_download || @info.file.closed?)
					return
				end
				
				# Increment download count after possible verification, as @info.bytes_received
				# starts counting at local filesize.
				@info.bytes_received += eventargs[0].length
				# Ack data, as 4 byte integer big-endian network byte order
				@tcp_con.send([@info.bytes_received].pack('N'))
				
				# Verify bytes if necessary
				if !@info.verification.verified
					if !self.verify_bytes(eventargs[0])
						@info.status = ON_DCC_ERROR
						self.fire_event(ON_DCC_ERROR, $cfg.text.network.dcc.err_verification)
						@tcp_con.close
						@info.file.close
						return	
					end
				elsif @info.verification.bytes_mine.length == @info.verification.bytes_their.length
					@info.verification.verified = true
					# Write remaining bytes to file
				else
					# All bytes have been eaten up by verification
					return
				end
					
				# Write to file
				@info.file.syswrite(eventargs[0])
				# Update MD5 if necessary
				@info.md5 << eventargs[0] if @info.md5
				# Update progress if necessary
				@info.progress_bytes += eventargs[0].length
				update_now = Time.now
				if (time_elapsed = update_now - @info.progress_timestamp) >= 5
					self.fire_event(
							ON_DCC_PROGRESS, 
							@info.bytes_received.to_f / @info.bytes_total * 100, 	# Percent done
							@info.bytes_received,									# Total number of received bytes
							(@info.progress_bytes.to_f / time_elapsed) / 1024)		# Speed
					@info.progress_bytes = 0
					@info.progress_timestamp = update_now
				end
				if @info.bytes_received == @info.bytes_total
					# Finished downloading
					@info.file.close if (@info.file && !@info.file.closed?)
					# Wait for the bot closing the connection
				end
				
		end
	end
	
	def verify_bytes(bytes)
		my_length = @info.verification.bytes_mine.length
		their_length = @info.verification.bytes_their.length
		return true if my_length == their_length
		startpos = their_length
		endpos = 0
		if their_length + bytes.length < my_length
			# All bytes are required for verification
			endpos = their_length + bytes.length - 1
			@info.verification.bytes_their << bytes.slice!(0..-1)
		else
			# Bytes are partly required for verification
			req_bytes = bytes.slice!(0..(my_length - their_length - 1))
			endpos = their_length + req_bytes.length - 1
			@info.verification.bytes_their << req_bytes
		end
		return @info.verification.bytes_their[startpos..endpos] == @info.verification.bytes_mine[startpos..endpos]	
	end
end