# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


require 'src/Network/DCC_File.rb'
require 'src/Utilities/Events.rb'
require 'src/Utilities/Timer.rb'

require 'digest/md5'

# Handles all downloads from a single bot.
# Only one pack at a time is allowed to be downloaded/queued from/at the bot. However,
# more than one pack may be added to the handler, which in turn will be stored in a local queue
# and be processed when a download finished/was cancelled.
# 
# Supports the generation of md5 sums on the fly. However, md5 is unavailable for resumed
# packs, as (of now) ruby does not support marshaling of md5 objects. Therefore, md5 context
# generation would require running through the entire (partly) downloaded file. As this would be 
# to time consuming, md5 support has been disabled for resumed packs. However, as soon as marshaling 
# md5 objects is supported in ruby, md5 support may come available for resumed packs.
#
# Handling multiple packs simultaneously from a single bot is very challenging, since the bot's
# status messages don't provide enough differentiation characteristics in order to assign them 
# to a single pack. Thats why only one pack is allowed at a time.
class XDCC_Download_Handler
	include Event_Publisher
	
	# Timer used for detecting various stalled cases
	@@timer = Timer.new(3)
	
	# The xdcc bot we are dealing with
	attr_reader :irc_user_bot
	# Current XDCC_Pack
	attr_reader :current_pack
	# Current XDCC_Pack status
	attr_reader :current_pack_status
	# Real filename of where pack is downloaded to
	attr_reader :current_pack_filename
	# ipaddr of bot we are connecting to
	
	# -- Connectable events
	
	# Before the Handler shuts down. Args: none
	ON_SHUTDOWN = Event_Publisher.next_global_eventID
	
	# When a pack gets requested. Args: pack
	ON_PACK_REQUESTED = Event_Publisher.next_global_eventID
	
	# When a pack is queued locally, because another pack is already in progress. 
	# Also triggered if an update of the local queue happens.
	# Args: pack, local queue position, local queue length
	ON_QUEUED_LOCALLY = Event_Publisher.next_global_eventID
	
	# When no free slots are available and the item gets remotely queued. 
	# Also triggered if an update of the remote queue happens
	# Args: pack, (remote queue position||nil)
	ON_QUEUED_REMOTELY = Event_Publisher.next_global_eventID
	
	# Whenever a download started. Args: pack, filename where pack data is stored to
	ON_DOWNLOAD_STARTED = Event_Publisher.next_global_eventID
	
	# Whenever a download finished. Args: pack
	ON_DOWNLOAD_FINISHED = Event_Publisher.next_global_eventID
	
	# When we receive a delayed md5 status. Args: pack, md5status
	ON_MD5_STATUS = Event_Publisher.next_global_eventID
	
	# Whenever a download failed. Args: pack, errormessage?
	ON_DOWNLOAD_FAILED = Event_Publisher.next_global_eventID
	
	# Every timespan_download_progress seconds (update of progress). 
	# Args: pack, percent completed, nr of bytes received, nr of kilo bytes per second 
	ON_DOWNLOAD_PROGRESS = Event_Publisher.next_global_eventID
	
	# All events packed in one
	ON_ALL_EVENTS = 	ON_SHUTDOWN|
						ON_PACK_REQUESTED|
						ON_QUEUED_LOCALLY|
						ON_QUEUED_REMOTELY|
						ON_DOWNLOAD_STARTED|
						ON_DOWNLOAD_FINISHED|
						ON_DOWNLOAD_FAILED|
						ON_DOWNLOAD_PROGRESS|
						ON_MD5_STATUS
						
	# -- Other constants
	
	# MD5 is disabled in the settings
	MD5_DISABLED = 0
	
	# MD5 is enabled, but we are waiting for a delayed md5 checksum message
	# MD5 is enabled, but pack was resumed
	MD5_UNAVAILABLE = 1
	
	# MD5 checksum matches the transferred data
	MD5_OK = 2
	
	# MD5 checksum failed to match transferred data
	MD5_FAILED = 3
	
						
	# Initialize with irc_user_bot
	def initialize(irc_user_bot)
		@mutex = Mutex.new						# Mutex used to synchronize
		@irc_user_bot = irc_user_bot
		@server = irc_user_bot.irc_server		# The server the bot is on
		@current_pack = nil						# Pack which has the focus of the handler
		@current_pack_status = -1				# Status of current pack. -1 indicates no status yet. Else one of the following:
												# ON_PACK_REQUESTED, ON_QUEUED_REMOTELY, ON_DOWNLOAD_STARTED, 
												# ON_DOWNLOAD_FINISHED
		@current_pack_md5 = nil					# MD5 object used for computation of md5 checksum for current_pack
		@last_packs = Array.new					# The packs we have dealt last with. Earlier packs are at the beginning of the queue
		@request_timestamp = nil				# The time the pack was requested
		@delay_timestamp = nil					# Timestamp when pack was delayed
		@delay_timeout = nil					# Timeout (secs) to pass by before requesting next pack
		@current_download_path = nil			# Path where to store the current pack
		@current_request_cnt = 0				# Number of times this pack was requested
		
		@local_pack_queue = Array.new			# Locally queued packs. Each element is a 2 element array of [pack, downloadpath]
		
		@server.connect_to_events(IRC_Server::ON_USER_MESSAGE |
		    						  IRC_Server::ON_USER_QUIT|
									  IRC_Server::ON_SERVER_DISCONNECTED,
									  self)
									  
		@server.dcc_parser.connect_to_events(DCC_Parser::ON_DCC_SEND, self)
		# Only one TCP connection is used per bot
		@dcc_con = DCC_File.new
		@dcc_con.connect_to_events(DCC_File::ON_ALL_EVENTS, self)
		@@timer.connect_to_events(Timer::ON_TIMER, self)
		self.init_events
	end
	
	# Disconnect from events, close all file/socket handles
	def shutdown
		@dcc_con.close
		@irc_user_bot.irc_server.disconnect_from_events(
				IRC_Server::ON_USER_MESSAGE |
				IRC_Server::ON_USER_QUIT|
				IRC_Server::ON_SERVER_DISCONNECTED, self)
		@server.dcc_parser.disconnect_from_events(DCC_Parser::ON_DCC_SEND, self)
		@@timer.disconnect_from_events(Timer::ON_TIMER, self)
	end
	
	# Add a pack to download and it's destination directory (without trailing deliminator)
	def add_pack(xdcc_pack, path)
		@mutex.synchronize do
			if !@current_pack && @local_pack_queue.empty?
				self.request_pack(xdcc_pack, path)
			else
				self.queue_pack(xdcc_pack, path)
			end
		end
	end
	
	# Request the given pack and set internal stati
	def request_pack(xdcc_pack, path)
		@request_timestamp = Time.now
		@current_request_cnt += 1
		@current_pack = xdcc_pack
		@current_pack_status = ON_PACK_REQUESTED
		@current_download_path = path
		@irc_user_bot.send("XDCC SEND ##{@current_pack.pack_nr}")
		self.fire_event(ON_PACK_REQUESTED, @current_pack)
	end
	
	# Queue pack locally
	def queue_pack(xdcc_pack, path)
		@local_pack_queue << [xdcc_pack, path]
		self.local_queue_change
	end
	
	# Prepare next pack (if there is one) for download.
	# If delay != 0, preparation of next pack will be delayed at least
	# delay seconds (depending on the timer)
	def next_pack(delay=0)
		@mutex.synchronize do
			# Enqueue all packs that have completed downloading and are waiting for
			# an md5 checksum from bot
			if $cfg.network.xdcc.enable_md5 && @current_pack_status == ON_DOWNLOAD_FINISHED && @current_pack_md5
				@last_packs << [@current_pack, @current_pack_md5]
			end
			@current_pack_md5 = nil
		end
		if delay > 0
			# Delayed request of next pack
			@delay_timestamp = Time.now
			@delay_timeout = delay
			return
		else
			@delay_timestamp = nil
		end
		@current_request_cnt = 0
		if !@local_pack_queue.empty?
			pack, path = @local_pack_queue.delete_at(0)
			self.request_pack(pack, path)
			# Update remaining queue positions
			self.local_queue_change
		else
			@mutex.synchronize do
				@current_pack = nil
				@current_pack_status = -1
				@current_download_path = nil
			end
		end
	end
	
	# Reset handler to empty state
	# There should not be any reason for this method to be called from outside
	def empty_state!
		@mutex.synchronize do
			@current_pack = nil
			@current_pack_status = -1
			@current_download_path = nil
			@delay_timestamp = nil
			@local_pack_queue.clear
		end
	end
	
	# Is the handler in empty state? (i.e contains no packs to download)
	def empty_state?
		@mutex.synchronize do
			!@current_pack && @current_pack_status == -1
		end
	end
	
	# Inform all ON_QUEUED_LOCALLY listeners that there was
	# an update in the local queue
	def local_queue_change
		length = @local_pack_queue.length
		@local_pack_queue.each_with_index do |pack_info, index|
			self.fire_event(ON_QUEUED_LOCALLY, pack_info[0], index + 1, length)
		end
	end
	
	# Cancel the specified pack using the given reason.
	# This works for packs that have one of the following stati:
	# ON_QUEUED_LOCALLY, ON_QUEUED_REMOTELY, ON_DOWNLOAD_STARTED
	def cancel_pack(xdcc_pack, reason=$cfg.text.network.xdcc.cancel_download_default)
		pack = nil
		nextpack = false
		@mutex.synchronize do
			if xdcc_pack == @current_pack 
				pack = @current_pack
				# Check if remotely queued
				if @current_pack_status == ON_QUEUED_REMOTELY
					@irc_user_bot.send("XDCC REMOVE")
					@current_pack_status = ON_DOWNLOAD_FAILED if pack
					self.fire_event(ON_DOWNLOAD_FAILED, pack, reason) if pack
					nextpack = true
				# Check if download started
				elsif @current_pack_status == ON_DOWNLOAD_STARTED
					@dcc_con.close if pack
					@current_pack_status = ON_DOWNLOAD_FAILED if pack
					self.fire_event(ON_DOWNLOAD_FAILED, pack, reason) if pack
					nextpack = true
				elsif @current_pack_status == ON_PACK_REQUESTED
					@dcc_con.close if pack
					@current_pack_status = ON_DOWNLOAD_FAILED if pack
					self.fire_event(ON_DOWNLOAD_FAILED, pack, reason) if pack
					nextpack = true
				end
			else
				# Check locally queued packs
				@local_pack_queue.delete_if do |p|
					ret = p[0] == xdcc_pack
					pack = xdcc_pack if ret
					self.fire_event(ON_DOWNLOAD_FAILED, pack, reason) if ret
					ret
				end
				# Update local queue
				self.local_queue_change if pack
			end
		end
		if next_pack
			self.next_pack(5)
		end
	end
	
	# Deal with delayed md5 checksum received from bot
	def handle_delayed_md5(received_md5)
		if !@last_packs.empty?
			pack, md5 = @last_packs.delete_at(0)
			return if !md5
			md5_ok = (md5.hexdigest == received_md5)
			self.fire_event(ON_MD5_STATUS, pack, md5_ok ? MD5_OK : MD5_FAILED)
		end
	end
		
	# Event handler
	def on_event(caller, event, eventargs)
		case event
			when IRC_Server::ON_USER_MESSAGE
				# Check for private bot message
				if (@irc_user_bot != eventargs[0] || !@server.me.has_name?(eventargs[2][0]))
					return
				end
				irc_msg = eventargs[3]
				message = eventargs[1]
				# Prolly a status update of the bot
				if status = $cfg.network.xdcc.queue_add_regexp.match(message)
					# Pack has been added to the remote queue.
					@current_pack_status = ON_QUEUED_REMOTELY
					self.fire_event(ON_QUEUED_REMOTELY, @current_pack, status[1].to_i, nil)
				elsif status = $cfg.network.xdcc.queue_full_regexp.match(message)
					# Queue is full, enqueue current pack and wait before requesting next pack
					self.add_pack(@current_pack, @current_download_path)
					self.next_pack($cfg.network.xdcc.queue_full_wait)
				elsif status = $cfg.network.xdcc.is_queued_regexp.match(message)
					# This shouldn't ever occur...
					@mutex.synchronize do 
						@current_pack_status = ON_DOWNLOAD_FAILED
					end
					self.fire_event(ON_DOWNLOAD_FAILED, @current_pack, $cfg.text.network.xdcc.err_pack_already_requested)
					self.next_pack($cfg.network.xdcc.is_queued_wait)
				elsif status = $cfg.network.xdcc.max_queued_regexp.match(message)
					# As shouldn't this...
					@mutex.synchronize do
						@current_pack_status = ON_DOWNLOAD_FAILED
					end
					self.fire_event(ON_DOWNLOAD_FAILED, @current_pack, $cfg.text.network.xdcc.err_max_packs_requested)
					self.next_pack($cfg.network.xdcc.max_queued_wait)
				elsif status = $cfg.network.xdcc.queue_update_regexp.match(message)
					# Remote queue position update
					@mutex.synchronize do
						@current_pack_status = ON_QUEUED_REMOTELY
					end
					self.fire_event(ON_QUEUED_REMOTELY, @current_pack, status[1].to_i, status[2].to_i)
				elsif status = $cfg.network.xdcc.md5_regexp.match(message)
					handle_delayed_md5(status[1])
				elsif status = $cfg.network.xdcc.punish_slowness_regexp.match(message)
					@mutex.synchronize do 
						@current_pack_status = ON_DOWNLOAD_FAILED
					end
					self.fire_event(ON_DOWNLOAD_FAILED, @current_pack, $cfg.text.network.xdcc.err_punish_slowness)
					@dcc_con.close
					self.next_pack(5)
				end
				
			
			when DCC_File::ON_DCC_ESTABLISHED
				@mutex.synchronize do
					@current_pack_status = ON_DOWNLOAD_STARTED
				end
				self.fire_event(ON_DOWNLOAD_STARTED, @current_pack)
			
			when DCC_File::ON_DCC_ERROR
				@mutex.synchronize do
					@current_pack_status = ON_DOWNLOAD_FAILED
				end
				self.fire_event(ON_DOWNLOAD_FAILED, @current_pack, eventargs[0])		
				# Give bot some time to close connection, before requesting next pack
				self.next_pack($cfg.network.xdcc.con_error_wait)
			
			when DCC_File::ON_DCC_COMPLETED
				@mutex.synchronize do
					@current_pack_status = ON_DOWNLOAD_FINISHED
					@current_pack_md5 = eventargs[0]
				end
				self.fire_event(ON_DOWNLOAD_FINISHED, @current_pack)
				self.fire_event(ON_MD5_STATUS, @current_pack, $cfg.network.xdcc.enable_md5 ? MD5_UNAVAILABLE : MD5_DISABLED)
				self.next_pack
				
			when DCC_File::ON_DCC_PROGRESS
				self.fire_event(ON_DOWNLOAD_PROGRESS, @current_pack, eventargs[0], eventargs[1], eventargs[2])
			
			when DCC_Parser::ON_DCC_SEND
				if (eventargs[0].irc_user == @irc_user_bot && (@current_pack_status == ON_PACK_REQUESTED ||
															   @current_pack_status == ON_QUEUED_REMOTELY))
					@dcc_con.get(eventargs[0], @current_download_path)
				end
				
			when Timer::ON_TIMER
				if @delay_timestamp
					# Next pack has been delayed. Check for end of delay.
					self.next_pack if eventargs[0] - @delay_timestamp >= @delay_timeout
				end
				
				@mutex.synchronize do
					if @current_pack_status == ON_PACK_REQUESTED
						if (eventargs[0] - @request_timestamp > $cfg.network.xdcc.request_timeout)
							if $cfg.network.xdcc.no_max_rerequests || (@current_request_cnt < $cfg.network.xdcc.max_rerequests)
								# No XDCC answer within specified interval. Rerequest pack
								self.request_pack(@current_pack, @current_download_path)
							else
								@current_pack_status = ON_DOWNLOAD_FAILED
								self.fire_event(ON_DOWNLOAD_FAILED, @current_pack, $cfg.text.network.xdcc.err_no_answer) 
								self.next_pack(20)
							end
						end
					end
				end
		end
	end
end