# Copyright (c) 2004-2005, Christoph Heindl
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification, 
# are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice, this list 
#      of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, this list 
#      of conditions and the following disclaimer in the documentation and/or other materials 
#      provided with the distribution.
#    * Neither the name of Christoph Heindl nor the names of its contributors may be used to 
#      endorse or promote products derived from this software without specific prior written 
#      permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
# AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


# Provides a convient interface for dealing with generic IRC messages.
# Name of irc users is always downcased for simplicity
class IRC_Message
	attr_accessor :name, :user, :host 	#prefix
	attr_accessor :command            	#command
	attr_reader :parameters           	#parameters
	
	# Construct a IRC_Message based on a command and variable length
	# command parameters
	def initialize(command=nil, *params)
		@name = nil
		@user = nil
		@parameters = Array.new
		@command = command
		@ctcp_reply = false
		@ctcp_command = false
		params.each do |param|
			self.add_parameter(param)
		end
	end
	
	# Add a parameter
	# If parameter equals a ctcp message, appropriate actions (\001 is being removed and internal stati are set) are taken.
	def add_parameter(param)
		if @parameters.length < 14
			if param =~ /^\001[^\001]*\001$/
				param.gsub!(/\001/, "")
				if @command == "PRIVMSG"
					@ctcp_command = true
				elsif @command == "NOTICE"
					@ctcp_reply = true
				end
			end
			@parameters.push(param)
		end
	end
	
	# Is a message prefix available
	def prefix?
		@name || (@user && @host)
	end
	
	# Is message origin a user or server
	def usermessage?
		self.prefix? && @user && @host
	end
	
	# Are there any parameters
	def parameters?
		@parameters.length > 0
	end
	
	# Does the message contain a non-irc standard ctcp part
	def ctcp?
		@ctcp_repy || @ctcp_command
	end
	
	# Is the message a ctcp command?
	def ctcp_command?
		@ctcp_command
	end
	
	# Is the message a ctcp reply?
	def ctcp_reply?
		@ctcp_reply
	end
	
	# Assemble an irc-protocol conform message.
	def to_s
		s = ""
		s += ":" + @name if self.prefix?
		s += "!" + @user + "@" + @host if self.usermessage?
		s += " " if self.prefix?
		s += @command
		parameters.each do |param|
			s += " "
			if param.include?(" ")
				s += ":"
				s += "\001" if self.ctcp?
				s += param
				s += "\001" if self.ctcp?
			else
				s += param
			end
		end
		s += "\r\n"
	end
	
	# -- class methods
	
	# Construct a IRC_Message object from a string. Returns a IRC_Message or nil on error
	def IRC_Message.parse(str)
		irc_msg = nil
		#split string into [prefix] command [arguments]
		str_no_crlf = str.chop
		if mdMessage = $cfg.network.irc.msg_regexp.match(str_no_crlf)
			irc_msg = IRC_Message.new
			#parse prefix if available
			if mdMessage[1] && mdPrefix = $cfg.network.irc.prefix_regexp.match(mdMessage[1])
				irc_msg.name = mdPrefix[1]
				irc_msg.user = mdPrefix[2] unless mdPrefix[2].empty?
				irc_msg.host = mdPrefix[3] unless mdPrefix[3].empty?
			end
			#set command
			irc_msg.command = mdMessage[2]
			#parse parameters if available
			if !mdMessage[3].empty?
				# parameter is either a string enclosed by spaces or the remainding line if parameter
				# starts with ':'
				mdMessage[3].scan($cfg.network.irc.params_regexp) do |param|
					# remove possible leading colons and trailing spaces and add to parameters
					irc_msg.add_parameter(param.sub(/^:/, "").sub(/\s*$/, ""))
				end
			end
		end
		irc_msg
	end
	
	# Delete any color codes, font modes from the given str
	# These control characters are based on the unofficial mirc implementation
	# Returns clean version of message
	# \002 => Bold
	# \003[??][,??] => Forground color, background color
	# \x0F => Switch back to plain mode
	# \x16 => Reverse mode
	# 0x1F => Underline
	def IRC_Message.delete_control_codes(str)
		str.gsub(/\002|\003(\d{1,2})?(,\d{1,2})?|\x0F|\x16|\x1F/, "")
	end
	
	# Deletes all trailing and leading spaces from a string
	# Returns clean string
	def IRC_Message.delete_spaces(str)
		str.gsub(/^\s+|\s+$/, "")
	end
end