REQUIREMENTS:
First you need to install these packages before you can launch xdcc-fetcher...

--- gentoo ---
Required libraries:
emerge -av media-libs/tiff

Required software:
emerge -av ruby fox stunnel
gem install fxruby

--- ubuntu ---
apt-get install ruby fox stunnel
gem install fxruby

--- HOW TO USE --

This application does need super user (root) extract it on your normal user home directory and use.

Execute ./run to launch the application it will connect to the server and start catching the packets, you need to wait more than 
10min before first packets will accour on the window. If you see warning icons with ! then something went wrong...

to create shortuct on your Gnome,KDE desktop simply run:
# ./run shortcut


--- Troubles ---

If you had some troubles running xdcc-fetcher and get messages like:

../lib/fox16.so: libtiff.so.4: cannot open shared object file: No such file or directory
../lib/fox16.so: libjpeg.so.62: cannot open shared object file: No such file or directory

You need to install proper libraries such as libtiff libjpeg !


if you had these libraries but the versions does not match then search for them using something like find /usr/lib -name 
libjpeg.so\* or find /usr/lib -name libtiff.so\*

Examples:

#find /usr/lib -name libtiff.so\*
# /usr/lib/libtiff.so.3.9.2
# /usr/lib/libtiff.so
# /usr/lib/libtiff.so.3

#find /usr/lib -name libjpeg.so\*
# /usr/lib/libjpeg.so.7.0.0
# /usr/lib/libjpeg.so.7
# /usr/lib/libjpeg.so

make symlinks
#cd /usr/lib
#ln -s /usr/lib/libjpeg.so libjpeg.so.62
#ln -s /usr/lib/libtiff.so libtiff.so.4

